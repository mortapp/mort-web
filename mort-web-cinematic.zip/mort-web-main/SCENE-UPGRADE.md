# MORT — cinematic scene upgrade

This is **your** `mort-web`, with the animated 3D world substantially built out —
new environmental systems added, everything animated, everything real 3D. Your
architecture (scene profiles, the `MortAtmosphere` mount, the drag-physics model,
the frame budget, fallbacks, routes, Supabase, server actions) is untouched. All
additions plug into `components/mort/scene/` exactly like your existing pieces and
are gated by profile + performance tier.

## New 3D systems (all animated at idle, drag-reactive where it fits)

| File | What it adds | Cinematic reference |
|---|---|---|
| `environment/longship.tsx` | A clinker-built **longship sailing the strait** — lathe hull, mast, a wind-rippling sail that bows harder with drag energy, a prow lantern. Sails across and wraps. Home gets a near + a far ship; auth gets one. | Vinland Saga |
| `environment/reflections.tsx` | **Light on the water** — a shimmering **moon-path** lane and a glow **pool beneath the Beacon**. This is what turns the flat dark sea into a cinematic one. | Your Name · 5cm/s |
| `environment/aurora.tsx` | **Aurora curtains** drifting over the sky — noise ribbons that breathe and slide, in MORT's ice-green/blue. | Your Name · Nagi-Asu |
| `environment/light-shafts.tsx` | **Volumetric light shafts** falling from the moon through the mist — soft additive blades that sway and breathe, giving the air depth. | Violet Evergarden · Garden of Words |
| `environment/birds.tsx` | A distant **flock crossing the sky** — dark chevrons that drift and flap, drawn as point sprites (a whole skein is nearly free). | Vinland Saga · Your Name |
| `environment/motes.tsx` | Drifting **light motes** — warm/cool glows that wander, bob, and lean away from the pointer. The living air of an iyashikei scene. | Mushishi · 5cm/s |
| `environment/meteors.tsx` | **Shooting stars** crossing the night on a staggered cycle — a bright head and fading tail. | Your Name |
| `environment/haze.tsx` | Layered **parallax haze banks** at several depths — drifting fog that gives the scene real atmospheric distance. | Mushishi · Garden of Words |

## Real physics (Rapier bodies, all reacting to your drag)

These run inside the existing `<Physics>` context alongside your `Fragments`,
using the same `drag-state` — so the pointer physically shoves them, then they
settle. Gravity stays `[0,0,0]`; motion comes from buoyancy, restoring springs,
turbulence and damping (your Fragments' Hooke's-law approach).

| File | What it does | Reference |
|---|---|---|
| `physics/lanterns.tsx` | **Paper lanterns as rigid bodies** — buoyancy lifts them, wind makes them wobble, a drag shoves them, they collide, and each respawns on the water when it clears the sky. A few carry real light. | A Silent Voice · Your Name |
| `physics/crystals.tsx` | **Iridescent crystals as rigid bodies** — each floats on a soft spring to its anchor, tumbling; a drag shoves and spins it, and hull colliders let a hard drag knock one crystal into another. Desktop-only. | Land of the Lustrous |
| `physics/drift.tsx` | A **physical petal field** across the whole scene — turbulence carries them, they tumble, scatter under a drag, and wrap around the play volume. | 5cm/s · Mushishi |

## The Passage — one unbroken shot through the Beacon (home · desktop)

Scrolling the hero now **flies the camera toward and *through* the Beacon** and
out into the next chapter — no cut, no fade. Driven entirely by scroll position,
on a pulse (0 → 1 at the core → 0) so the camera returns to the normal framing
afterward and the rest of the page behaves exactly as before.

- `components/mort/scene/world.tsx` (**CameraRig**) — during the passage the camera
  dollies forward toward the Beacon and looks into its core, then eases back out.
  Gated to `home` + desktop; mobile and every other profile are untouched.
- `beacon.tsx` — the Beacon **opens**: rings splay wide and spin up, the core blooms,
  and a portal bloom grows as you pass through.
- `environment/passage.tsx` — a **light-warp** locked to the camera: radial streaks
  stretching from a bright core, flashing only at the moment of passing through,
  gone at rest.

Everything is scroll-position-driven (not time), so it tracks the user both ways;
reduced-motion users never mount the world, so they never see it.

## The Crossing widget now sails

`components/mort/scene/voyage-canvas.tsx` — the little ship on the lifecycle curve
is now a **longship that continuously sails the whole route**: it travels the
Catmull-Rom curve, banks into the turns, bobs, lights each checkpoint as it passes
(the selected stop still lights the path up to it), and loops by fading through the
seam. A living voyage, matching the animated-background feel — responsive via the
existing width-fit ortho camera, paused when the section is off-screen.

## Elevated

- **`beacon.tsx`** — rebuilt as the definitive **MORT Beacon**: matte-black tapered
  spar in the water, brushed-silver + ice **counter-rotating rings** (with orbiting
  nodes so the spin reads), a frosted-glass faceted core housing, a **breathing
  ice-blue core**, filament and halo. Leans toward the pointer; rings **spin up with
  drag velocity**.

## Wiring (one file)

- **`world.tsx`** — imports and mounts the six systems above with profile gating and
  perf scaling (fewer birds/motes on mobile/low-power; shafts off on low-power; the
  app profile stays restrained). The Beacon mount now passes `drag`. Nothing else
  changed.

## Where each shows up

- **Home** — aurora, light shafts, birds, meteors, haze, the near + far longship,
  rising lanterns, iridescent crystals, moon-path + Beacon glow pool, motes, and
  the Beacon.
- **Safety** — aurora (dimmer), shafts, birds, meteors, stronger haze, rising
  lanterns, moon-path over the guarded crossing, motes.
- **Auth** — a moored-feeling longship, rising lanterns, warm moon-path, aurora,
  shafts, birds, meteors, haze, motes.
- **Legal** — rain/archive mood kept; haze thickens it (reflections/motes/lanterns
  deliberately skipped).
- **App** — stays restrained: none of the loud additions mount here.

Crystals are desktop-only (transmission is the one expensive material); lanterns,
birds, motes and meteors scale down on mobile / low-power; shafts and meteors and
crystals drop entirely on the low-power tier.

## Verified against your exact toolchain

- `npm run typecheck` → **clean**
- `npm test` → **5/5 pass** (drag-state + scene-profile contracts intact)
- `npm run build` → **green**, all routes compile
- Live render (`next start` + WebGL) on `/`, `/safety`, `/login`: worlds mount,
  `data-scene-status=running`, **no console/page errors**; ship, aurora, shafts,
  reflections and birds all animate.

## Env & performance

`.env.local` is not included (your Vercel env is untouched; a placeholder was used
only to run the build/render check, then removed). Every new system uses
`Math.min(delta, .05)` clamps, additive/point-sprite draws, and profile/perf gating,
so it rides your existing frame budget. If you want any element dialed up or down,
each is a single self-contained file with obvious constants (counts, intensities,
positions).

## Optional next (say the word)

- A scroll-driven **no-cut "passage"** where the camera travels *through* the Beacon
  between chapters (from the design canvas).
- **Floating lanterns** rising on Safety/Destination (A Silent Voice).
- **Refractive crystal drift** (Land of the Lustrous) as an alternate to motes.
