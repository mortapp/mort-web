import { useRef, type RefObject } from 'react'
import { useBeforePhysicsStep, RigidBody, type RapierRigidBody } from '@react-three/rapier'
import type { DragState } from '../input/drag-state'
import type { SceneProfile } from '../profile'

// Iridescent crystals as REAL physics bodies (Land of the Lustrous). Each floats
// on a soft spring toward its anchor, tumbling slowly; a drag shoves and spins it
// and it drifts back. They carry hull colliders, so a hard drag can knock one
// crystal into another. Desktop-only — the transmissive material is the one
// costly thing in the scene.
function PhysicsCrystal({ seed, drag }: { seed: number; drag: RefObject<DragState> }) {
  const body = useRef<RapierRigidBody>(null)
  const t = useRef(seed * 2)
  const lastSequence = useRef(0)
  const r = (n: number) => { const s = Math.sin(seed * 33.7 + n) * 43758.5453; return s - Math.floor(s) }
  const anchor = { x: (r(1) - 0.5) * 22, y: 1.8 + r(2) * 3, z: -9 - r(3) * 14 }
  const scale = 0.5 + r(4) * 0.7

  useBeforePhysicsStep(() => {
    const rb = body.current
    if (!rb) return
    t.current += 1 / 60
    const p = rb.translation(), v = rb.linvel()
    // soft restoring spring toward the anchor + buoyant wobble + damping
    rb.resetForces(false)
    rb.addForce({
      x: (anchor.x - p.x) * 0.5 - v.x * 0.4 + Math.sin(t.current * 0.4 + seed) * 0.05,
      y: (anchor.y - p.y) * 0.5 - v.y * 0.4 + Math.sin(t.current * 0.5 + seed) * 0.06,
      z: (anchor.z - p.z) * 0.5 - v.z * 0.4,
    }, true)
    // keep it turning gently at rest
    rb.applyTorqueImpulse({ x: 0.0008, y: 0.0011, z: 0.0006 }, true)
    // a drag shoves and spins it
    if (lastSequence.current !== drag.current.sequence) {
      lastSequence.current = drag.current.sequence
      const d = drag.current
      const x = (d.x / window.innerWidth - 0.5) * 24, y = (0.5 - d.y / window.innerHeight) * 14
      const influence = Math.exp(-Math.hypot(p.x - x, p.y - y) * 0.2)
      rb.applyImpulse({ x: d.vx * influence * 0.2, y: -d.vy * influence * 0.2, z: -d.energy * influence * 0.1 }, true)
      rb.applyTorqueImpulse({ x: d.vy * 0.01, y: d.vx * 0.01, z: d.energy * 0.008 }, true)
    }
  })
  return (
    <RigidBody ref={body} position={[anchor.x, anchor.y, anchor.z]} colliders="hull" linearDamping={0.8} angularDamping={0.9} mass={0.5} canSleep={false}>
      <mesh scale={[scale * 0.5, scale * 1.3, scale * 0.5]}>
        <octahedronGeometry args={[1, 0]} />
        <meshPhysicalMaterial
          color="#eaf3ff"
          transmission={0.82}
          thickness={1.2}
          ior={1.7}
          roughness={0.06}
          metalness={0}
          clearcoat={1}
          clearcoatRoughness={0.05}
          iridescence={1}
          iridescenceIOR={1.35}
          iridescenceThicknessRange={[120, 420]}
          attenuationColor="#bcd6ff"
          attenuationDistance={2.4}
          emissive="#20344f"
          emissiveIntensity={0.25}
        />
      </mesh>
      <mesh scale={scale * 0.16}>
        <octahedronGeometry args={[1, 0]} />
        <meshBasicMaterial color="#eaf4ff" />
      </mesh>
    </RigidBody>
  )
}
export function PhysicsCrystals({ count, drag, profile }: { count: number; drag: RefObject<DragState>; profile: SceneProfile }) {
  if (profile !== 'home') return null
  return <>{Array.from({ length: count }, (_, i) => <PhysicsCrystal key={i} seed={i + 1} drag={drag} />)}</>
}
