import { useRef, type RefObject } from 'react'
import { useFrame } from '@react-three/fiber'
import { useBeforePhysicsStep, RigidBody, BallCollider, type RapierRigidBody } from '@react-three/rapier'
import { AdditiveBlending, Mesh } from 'three'
import type { DragState } from '../input/drag-state'
import type { SceneProfile } from '../profile'

// Paper lanterns as REAL physics bodies (A Silent Voice · Your Name). Buoyancy
// lifts them, viscous damping settles them into a gentle rise, a wandering wind
// force makes them wobble, and a drag near them shoves them for real — then they
// bob back. When one clears the sky it respawns on the water. They also collide,
// so a shove ripples through the flock.
function PhysicsLantern({ seed, lit, drag }: { seed: number; lit: boolean; drag: RefObject<DragState> }) {
  const body = useRef<RapierRigidBody>(null)
  const halo = useRef<Mesh>(null)
  const t = useRef(seed * 5)
  const lastSequence = useRef(0)
  const r = (n: number) => { const s = Math.sin(seed * 51.3 + n) * 43758.5453; return s - Math.floor(s) }
  const spawnX = (r(1) - 0.5) * 40
  const z = -8 - r(2) * 40

  useBeforePhysicsStep(() => {
    const rb = body.current
    if (!rb) return
    t.current += 1 / 60
    const p = rb.translation(), v = rb.linvel()
    // respawn when it clears the top of the sky
    if (p.y > 17) {
      rb.setTranslation({ x: spawnX + (r(7) - 0.5) * 4, y: -1.6, z }, true)
      rb.setLinvel({ x: 0, y: 0, z: 0 }, true)
      return
    }
    // buoyancy up + viscous damping + a slow wandering wind
    rb.resetForces(false)
    rb.addForce({
      x: Math.sin(t.current * 0.5 + seed) * 0.06 - v.x * 0.6,
      y: 0.62 - v.y * 0.5,
      z: Math.cos(t.current * 0.4 + seed) * 0.04 - v.z * 0.6,
    }, true)
    // a drag near the lantern gives it a real push
    if (lastSequence.current !== drag.current.sequence) {
      lastSequence.current = drag.current.sequence
      const d = drag.current
      const x = (d.x / window.innerWidth - 0.5) * 24, y = (0.5 - d.y / window.innerHeight) * 14
      const influence = Math.exp(-Math.hypot(p.x - x, p.y - y) * 0.24)
      rb.applyImpulse({ x: d.vx * influence * 0.12, y: -d.vy * influence * 0.12, z: -d.energy * influence * 0.05 }, true)
    }
  })
  useFrame(() => {
    if (halo.current) {
      const pulse = 0.4 + 0.18 * Math.sin(t.current * 2 + seed)
      const m = halo.current.material as { opacity: number }
      m.opacity = pulse
    }
  })
  return (
    <RigidBody ref={body} position={[spawnX, -1.6, z]} colliders={false} linearDamping={0.9} angularDamping={2} mass={0.2} canSleep={false}>
      <BallCollider args={[0.2]} />
      <mesh>
        <cylinderGeometry args={[0.14, 0.12, 0.32, 8]} />
        <meshBasicMaterial color="#ffcaa0" />
      </mesh>
      <mesh position={[0, -0.2, 0]}>
        <sphereGeometry args={[0.05, 6, 6]} />
        <meshBasicMaterial color="#ff9a5a" />
      </mesh>
      <mesh ref={halo}>
        <sphereGeometry args={[0.55, 12, 10]} />
        <meshBasicMaterial color="#ffb877" transparent opacity={0.4} depthWrite={false} blending={AdditiveBlending} />
      </mesh>
      {lit && <pointLight intensity={2} distance={5} decay={2} color="#ffb877" />}
    </RigidBody>
  )
}
export function PhysicsLanterns({ count, drag, profile }: { count: number; drag: RefObject<DragState>; profile: SceneProfile }) {
  if (profile === 'app' || profile === 'legal') return null
  return <>{Array.from({ length: count }, (_, i) => <PhysicsLantern key={i} seed={i + 1} lit={i % 3 === 0} drag={drag} />)}</>
}
