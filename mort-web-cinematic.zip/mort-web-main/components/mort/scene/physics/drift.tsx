import { useRef, type RefObject } from 'react'
import { useBeforePhysicsStep, RigidBody, BallCollider, type RapierRigidBody } from '@react-three/rapier'
import { DoubleSide } from 'three'
import type { DragState } from '../input/drag-state'
import type { SceneProfile } from '../profile'

// A field of drifting petals as REAL physics bodies — turbulence carries them,
// they tumble, they scatter under a drag, and they wrap around the scene so the
// whole air is physically alive (not just the fragments around the Beacon).
function Petal({ seed, drag, tint }: { seed: number; drag: RefObject<DragState>; tint: string }) {
  const body = useRef<RapierRigidBody>(null)
  const t = useRef(seed * 1.7)
  const lastSequence = useRef(0)
  const r = (n: number) => { const s = Math.sin(seed * 19.7 + n) * 43758.5453; return s - Math.floor(s) }
  const start = { x: (r(1) - 0.5) * 38, y: 0.5 + r(2) * 11, z: -6 - r(3) * 34 }

  useBeforePhysicsStep(() => {
    const rb = body.current
    if (!rb) return
    t.current += 1 / 60
    const p = rb.translation(), v = rb.linvel()
    // wrap around the play volume
    let wrapped = false
    const nx = p.x < -22 ? 22 : p.x > 22 ? -22 : p.x
    const ny = p.y < -2 ? 12 : p.y > 13 ? -1 : p.y
    const nz = p.z < -44 ? -6 : p.z > -4 ? -40 : p.z
    if (nx !== p.x || ny !== p.y || nz !== p.z) wrapped = true
    if (wrapped) { rb.setTranslation({ x: nx, y: ny, z: nz }, true); rb.setLinvel({ x: 0, y: 0, z: 0 }, true); return }
    // turbulent wind + slight buoyancy + damping
    rb.resetForces(false)
    rb.addForce({
      x: Math.sin(t.current * 0.6 + seed) * 0.05 + Math.cos(t.current * 0.23 + seed * 2) * 0.03 - v.x * 0.5,
      y: 0.05 + Math.sin(t.current * 0.5 + seed) * 0.04 - v.y * 0.5,
      z: Math.cos(t.current * 0.4 + seed) * 0.03 - v.z * 0.5,
    }, true)
    rb.applyTorqueImpulse({ x: 0.0003, y: 0.0004, z: 0.0002 }, true)
    // scatter on drag
    if (lastSequence.current !== drag.current.sequence) {
      lastSequence.current = drag.current.sequence
      const d = drag.current
      const x = (d.x / window.innerWidth - 0.5) * 24, y = (0.5 - d.y / window.innerHeight) * 14
      const influence = Math.exp(-Math.hypot(p.x - x, p.y - y) * 0.26)
      rb.applyImpulse({ x: d.vx * influence * 0.14, y: -d.vy * influence * 0.14, z: -d.energy * influence * 0.06 }, true)
      rb.applyTorqueImpulse({ x: d.vy * 0.004, y: d.vx * 0.004, z: 0 }, true)
    }
  })
  return (
    <RigidBody ref={body} position={[start.x, start.y, start.z]} colliders={false} linearDamping={1.1} angularDamping={1.4} mass={0.08} canSleep={false}>
      <BallCollider args={[0.12]} />
      <mesh rotation={[seed, seed * 2, seed * 0.5]}>
        <planeGeometry args={[0.24, 0.13]} />
        <meshStandardMaterial color={tint} side={DoubleSide} metalness={0.2} roughness={0.7} transparent opacity={0.9} />
      </mesh>
    </RigidBody>
  )
}
export function PhysicsDrift({ count, drag, profile }: { count: number; drag: RefObject<DragState>; profile: SceneProfile }) {
  if (profile === 'app') return null
  const tint = profile === 'legal' ? '#9fb6c6' : profile === 'safety' ? '#b9cfe0' : '#dfe7f0'
  return <>{Array.from({ length: count }, (_, i) => <Petal key={i} seed={i + 1} drag={drag} tint={tint} />)}</>
}
