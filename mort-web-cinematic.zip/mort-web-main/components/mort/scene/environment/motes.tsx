import { useMemo, useRef, type RefObject } from 'react'
import { useFrame } from '@react-three/fiber'
import { AdditiveBlending, BufferAttribute, Points, ShaderMaterial, Vector2 } from 'three'
import type { DragState } from '../input/drag-state'

// Drifting light motes — the quiet, living air of an iyashikei scene (Mushishi ·
// 5 Centimeters). Warm and cool glows that wander and bob, and lean away from
// the pointer. GPU-driven, so the count is nearly free.
export function Motes({ count, drag }: { count: number; drag: RefObject<DragState> }) {
  const mat = useRef<ShaderMaterial>(null)
  const t = useRef(0)
  const geo = useMemo(() => {
    const pos = new Float32Array(count * 3)
    const seed = new Float32Array(count)
    for (let i = 0; i < count; i++) {
      const r = (n: number) => { const s = Math.sin(i * 12.9898 + n) * 43758.5453; return s - Math.floor(s) }
      pos[i * 3] = (r(1) - 0.5) * 46
      pos[i * 3 + 1] = r(2) * 12 + 0.5
      pos[i * 3 + 2] = -6 - r(3) * 34
      seed[i] = r(4)
    }
    return { pos, seed }
  }, [count])
  const uniforms = useMemo(
    () => ({ uTime: { value: 0 }, uPointer: { value: new Vector2() }, uForce: { value: 0 } }),
    [],
  )
  useFrame((_, delta) => {
    t.current += Math.min(delta, 0.05)
    if (!mat.current) return
    mat.current.uniforms.uTime.value = t.current
    mat.current.uniforms.uForce.value = drag.current.energy
    mat.current.uniforms.uPointer.value.set(
      (drag.current.x / window.innerWidth - 0.5) * 26,
      (0.5 - drag.current.y / window.innerHeight) * 15,
    )
  })
  return (
    <points frustumCulled={false}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[geo.pos, 3]} />
        <bufferAttribute attach="attributes-seed" args={[geo.seed, 1]} />
      </bufferGeometry>
      <shaderMaterial
        ref={mat}
        transparent
        depthWrite={false}
        blending={AdditiveBlending}
        uniforms={uniforms}
        vertexShader={`
          uniform float uTime,uForce;uniform vec2 uPointer;attribute float aSeed;
          varying float vSeed;varying float vTw;
          void main(){
            vSeed=aSeed;
            vec3 p=position;
            p.x+=sin(uTime*(.15+aSeed*.2)+aSeed*6.28)*1.6;
            p.y+=sin(uTime*(.22+aSeed*.15)+aSeed*10.)*.9;
            p.z+=cos(uTime*.12+aSeed*8.)*1.1;
            vec2 away=p.xy-uPointer;float d=length(away);
            p.xy+=normalize(away+1e-4)*exp(-d*.25)*uForce*2.2;
            vTw=.55+.45*sin(uTime*(1.+aSeed*2.)+aSeed*20.);
            vec4 mv=modelViewMatrix*vec4(p,1.);
            gl_Position=projectionMatrix*mv;
            gl_PointSize=clamp(120./-mv.z,2.,11.)*(.6+aSeed*.8);
          }`}
        fragmentShader={`
          varying float vSeed;varying float vTw;
          void main(){
            float d=length(gl_PointCoord-.5);
            float a=smoothstep(.5,0.,d)*vTw;
            vec3 warm=vec3(1.,.83,.55),cool=vec3(.62,.78,1.);
            vec3 col=mix(cool,warm,step(.72,vSeed));
            gl_FragColor=vec4(col,a*.6);
          }`}
      />
    </points>
  )
}
