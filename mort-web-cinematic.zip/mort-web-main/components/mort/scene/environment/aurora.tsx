import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { AdditiveBlending, Color, ShaderMaterial } from 'three'
import type { SceneProfile } from '../profile'

// Aurora curtains drifting over the strait (Your Name · Nagi-Asu). Vertical
// noise ribbons that breathe and slide, additive over the sky. Cool ice-green
// so it stays inside MORT's palette. Hidden inside the app.
export function Aurora({ profile }: { profile: SceneProfile }) {
  const mat = useRef<ShaderMaterial>(null)
  const t = useRef(0)
  const uniforms = useMemo(
    () => ({
      uTime: { value: 0 },
      uColorA: { value: new Color('#8fd4c8') },
      uColorB: { value: new Color('#9cc0ee') },
      uIntensity: { value: profile === 'safety' ? 0.85 : profile === 'auth' ? 1.1 : 1.5 },
    }),
    [profile],
  )
  useFrame((_, delta) => {
    t.current += Math.min(delta, 0.05)
    if (mat.current) mat.current.uniforms.uTime.value = t.current
  })
  if (profile === 'app' || profile === 'legal') return null
  return (
    <mesh position={[0, 22, -116]} rotation={[0.06, 0, 0]}>
      <planeGeometry args={[320, 96]} />
      <shaderMaterial
        ref={mat}
        transparent
        depthWrite={false}
        blending={AdditiveBlending}
        uniforms={uniforms}
        vertexShader={`varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`}
        fragmentShader={`
          uniform float uTime,uIntensity;uniform vec3 uColorA,uColorB;varying vec2 vUv;
          float hash(vec2 p){vec3 q=fract(vec3(p.xyx)*.1031);q+=dot(q,q.yzx+33.33);return fract((q.x+q.y)*q.z);}
          float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}
          float fbm(vec2 p){float v=0.,a=.5;for(int i=0;i<4;i++){v+=a*noise(p);p=p*2.02+11.3;a*=.5;}return v;}
          void main(){
            vec2 p=vUv;
            float curtain=fbm(vec2(p.x*3.4+uTime*.045,p.y*1.5-uTime*.02));
            curtain*=fbm(vec2(p.x*9.-uTime*.03,p.y*3.));
            float band=smoothstep(.05,.5,p.y)*smoothstep(1.,.55,p.y);
            float rays=pow(max(0.,sin(p.x*40.+curtain*7.)*.5+.5),3.);
            float a=curtain*band*(.28+rays*.5)*uIntensity;
            vec3 col=mix(uColorA,uColorB,p.y+sin(p.x*6.+uTime*.1)*.2);
            gl_FragColor=vec4(col,a);
          }`}
      />
    </mesh>
  )
}
