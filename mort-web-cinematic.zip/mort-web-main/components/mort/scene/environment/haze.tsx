import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { ShaderMaterial } from 'three'
import type { SceneProfile } from '../profile'

// Layered haze banks at several depths — soft fog drifting between the camera
// and the far shore (Mushishi · Garden of Words). Parallax between the layers is
// what gives the scene real atmospheric distance.
const noise = `
float hash(vec2 p){vec3 q=fract(vec3(p.xyx)*.1031);q+=dot(q,q.yzx+33.33);return fract((q.x+q.y)*q.z);}
float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}
float fbm(vec2 p){float v=0.,a=.5;for(int i=0;i<3;i++){v+=a*noise(p);p=p*2.03+7.1;a*=.5;}return v;}`

function Bank({ z, y, speed, opacity, width }: { z: number; y: number; speed: number; opacity: number; width: number }) {
  const mat = useRef<ShaderMaterial>(null)
  const t = useRef(z)
  const uniforms = useMemo(() => ({ uTime: { value: 0 }, uOpacity: { value: opacity } }), [opacity])
  useFrame((_, d) => { t.current += Math.min(d, 0.05); if (mat.current) mat.current.uniforms.uTime.value = t.current })
  return (
    <mesh position={[0, y, z]}>
      <planeGeometry args={[width, 22]} />
      <shaderMaterial
        ref={mat}
        transparent
        depthWrite={false}
        uniforms={uniforms}
        vertexShader={`varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`}
        fragmentShader={`uniform float uTime,uOpacity;varying vec2 vUv;${noise}
          void main(){
            float n=fbm(vec2(vUv.x*6.-uTime*${speed.toFixed(3)},vUv.y*3.));
            float band=smoothstep(.0,.35,vUv.y)*smoothstep(1.,.5,vUv.y);
            float a=smoothstep(.3,.8,n)*band*uOpacity;
            gl_FragColor=vec4(vec3(.72,.80,.88),a);
          }`}
      />
    </mesh>
  )
}
export function Haze({ profile }: { profile: SceneProfile }) {
  if (profile === 'app') return null
  const strong = profile === 'legal' || profile === 'safety'
  return (
    <group>
      <Bank z={-14} y={0.5} speed={0.05} opacity={strong ? 0.16 : 0.1} width={70} />
      <Bank z={-40} y={2} speed={0.03} opacity={strong ? 0.2 : 0.14} width={130} />
      <Bank z={-72} y={4} speed={0.018} opacity={strong ? 0.24 : 0.16} width={200} />
    </group>
  )
}
