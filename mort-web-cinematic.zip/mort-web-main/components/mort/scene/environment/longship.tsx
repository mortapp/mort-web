import { useMemo, useRef, type RefObject } from 'react'
import { useFrame } from '@react-three/fiber'
import { DoubleSide, Group, LatheGeometry, ShaderMaterial, Vector2 } from 'three'
import type { DragState } from '../input/drag-state'

// A clinker-built longship crossing the strait — the voyage made literal
// (Vinland Saga). Hull turned on a lathe, a mast, and a wind-rippling sail whose
// billow answers to drag energy. It sails slowly across the far water, bobbing,
// and wraps. Present on the open chapters, hidden inside the restrained app.
export function Longship({ drag, far = false }: { drag: RefObject<DragState>; far?: boolean }) {
  const group = useRef<Group>(null)
  const sailMat = useRef<ShaderMaterial>(null)
  const time = useRef(0)

  // hull as a lathe profile (a lean, upswept boat section)
  const hull = useMemo(() => {
    const pts = [
      new Vector2(0.02, 0), new Vector2(0.5, 0.02), new Vector2(0.85, 0.1),
      new Vector2(1.0, 0.28), new Vector2(0.98, 0.5), new Vector2(0.7, 0.62),
    ]
    return new LatheGeometry(pts, 24)
  }, [])

  const sailUniforms = useMemo(() => ({ uTime: { value: 0 }, uForce: { value: 0 } }), [])

  useFrame((_, delta) => {
    const dt = Math.min(delta, 0.05)
    time.current += dt
    const t = time.current
    if (group.current) {
      const span = 40
      const x = ((t * (far ? 0.32 : 0.5) + span / 2) % span) - span / 2
      group.current.position.x = far ? -x : x
      group.current.position.y = (far ? -1.95 : -1.62) + Math.sin(t * 0.7) * 0.13
      group.current.rotation.z = Math.sin(t * 0.7) * 0.035
      group.current.rotation.x = Math.sin(t * 0.5) * 0.02
    }
    if (sailMat.current) {
      sailMat.current.uniforms.uTime.value = t
      sailMat.current.uniforms.uForce.value = drag.current.energy
    }
  })

  const scale = far ? 0.85 : 1.5
  return (
    <group ref={group} position={[0, -1.7, far ? -54 : -29]} rotation={[0, Math.PI * 0.5, 0]} scale={scale}>
      {/* hull — laid on its side so the lathe axis runs bow-to-stern */}
      <mesh geometry={hull} rotation={[0, 0, -Math.PI / 2]} scale={[0.9, 3.1, 0.9]}>
        <meshStandardMaterial color="#161c22" metalness={0.35} roughness={0.7} side={DoubleSide} />
      </mesh>
      {/* gunwale highlight */}
      <mesh position={[0, 0.28, 0]} scale={[0.02, 0.02, 3]}>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color="#aeb9c6" metalness={0.8} roughness={0.3} />
      </mesh>
      {/* mast */}
      <mesh position={[0, 1.4, 0]}>
        <cylinderGeometry args={[0.03, 0.045, 2.8, 6]} />
        <meshStandardMaterial color="#20272e" metalness={0.4} roughness={0.6} />
      </mesh>
      {/* sail — a rippling cloth that bows with the wind (and with drag) */}
      <mesh position={[0, 1.55, 0.02]}>
        <planeGeometry args={[2.4, 1.9, 24, 16]} />
        <shaderMaterial
          ref={sailMat}
          side={DoubleSide}
          uniforms={sailUniforms}
          vertexShader={`uniform float uTime,uForce;varying float vShade;void main(){vec3 p=position;float b=(0.18+abs(uv.x-.5)*0.9)*(1.+uForce*1.6);p.z+=sin(p.x*1.6-uTime*1.7)*b+sin(p.y*1.1-uTime*1.2)*b*.4;vShade=p.z;gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.);}`}
          fragmentShader={`varying float vShade;void main(){vec3 c=mix(vec3(.62,.66,.72),vec3(.90,.93,.97),smoothstep(-.5,.5,vShade));gl_FragColor=vec4(c,1.);}`}
        />
      </mesh>
      {/* lantern at the prow */}
      <mesh position={[0, 0.5, 1.5]}>
        <sphereGeometry args={[0.06, 8, 6]} />
        <meshBasicMaterial color="#ffdca0" />
      </mesh>
      <pointLight position={[0, 0.6, 1.5]} intensity={1.4} distance={3} color="#ffd39a" />
    </group>
  )
}
