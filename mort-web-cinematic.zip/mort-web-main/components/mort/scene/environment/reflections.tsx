import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { AdditiveBlending, ShaderMaterial } from 'three'
import type { SceneProfile } from '../profile'

// Light on the water — a shimmering moon-path and a pool of glow beneath the
// Beacon (Your Name · 5 Centimeters). Additive planes lying on the surface, so
// the dark foreground fills with moving reflected light. This is what turns a
// flat sea into a cinematic one.
export function Reflections({ profile }: { profile: SceneProfile }) {
  const moonPath = useRef<ShaderMaterial>(null)
  const pool = useRef<ShaderMaterial>(null)
  const t = useRef(0)
  const uMoon = useMemo(() => ({ uTime: { value: 0 }, uWarm: { value: profile === 'auth' ? 1 : 0 } }), [profile])
  const uPool = useMemo(() => ({ uTime: { value: 0 } }), [])
  useFrame((_, d) => {
    t.current += Math.min(d, 0.05)
    if (moonPath.current) moonPath.current.uniforms.uTime.value = t.current
    if (pool.current) pool.current.uniforms.uTime.value = t.current
  })
  if (profile === 'legal') return null
  const moonX = profile === 'safety' ? -14 : 15
  return (
    <group>
      {/* moon-path: a long shimmering lane from the moon toward the camera */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[moonX * 0.5, -2.18, -22]}>
        <planeGeometry args={[9, 150, 1, 60]} />
        <shaderMaterial
          ref={moonPath}
          transparent
          depthWrite={false}
          blending={AdditiveBlending}
          uniforms={uMoon}
          vertexShader={`varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`}
          fragmentShader={`uniform float uTime,uWarm;varying vec2 vUv;
            void main(){
              float across=1.-abs(vUv.x-.5)*2.;across=pow(max(0.,across),1.6);
              float ripple=.5+.5*sin(vUv.y*120.-uTime*3.)*sin(vUv.y*38.+uTime*1.5);
              float shimmer=pow(ripple,3.)*across;
              float depth=smoothstep(0.,.15,vUv.y);
              vec3 cool=vec3(.62,.74,.92),warm=vec3(1.,.86,.62);
              vec3 col=mix(cool,warm,uWarm);
              gl_FragColor=vec4(col,shimmer*depth*.5);
            }`}
        />
      </mesh>
      {/* glow pool beneath the Beacon */}
      {(profile === 'home' || profile === 'app') && (
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[4.5, -2.17, -3]}>
          <circleGeometry args={[3.4, 48]} />
          <shaderMaterial
            ref={pool}
            transparent
            depthWrite={false}
            blending={AdditiveBlending}
            uniforms={uPool}
            vertexShader={`varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`}
            fragmentShader={`uniform float uTime;varying vec2 vUv;
              void main(){
                float d=length(vUv-.5)*2.;
                float glow=smoothstep(1.,0.,d);
                float rip=.6+.4*sin(d*24.-uTime*2.5);
                gl_FragColor=vec4(vec3(.66,.8,1.),glow*glow*rip*.6);
              }`}
          />
        </mesh>
      )}
    </group>
  )
}
