import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { AdditiveBlending, Group, Mesh } from 'three'
import type { SceneProfile } from '../profile'

// Shooting stars crossing the night (Your Name) — rare, quick, staggered so one
// streaks every few seconds. A stretched additive blade with a bright head and a
// fading tail. Pure sky decoration; off inside the app.
function Meteor({ seed }: { seed: number }) {
  const group = useRef<Group>(null)
  const blade = useRef<Mesh>(null)
  const t = useRef(seed * 4.5)
  const r = (n: number) => { const s = Math.sin(seed * 71.9 + n) * 43758.5453; return s - Math.floor(s) }
  const period = 7 + r(1) * 9
  const startX = 30 + r(2) * 20
  const y = 14 + r(3) * 16
  const z = -70 - r(4) * 30
  const dur = 1.3
  useFrame((_, d) => {
    t.current += Math.min(d, 0.05)
    const local = t.current % period
    const active = local < dur
    if (group.current) group.current.visible = active
    if (active && group.current) {
      const p = local / dur
      group.current.position.set(startX - p * 46, y - p * 14, z)
    }
    if (blade.current) {
      const p = local / dur
      const fade = Math.sin(Math.min(1, p) * Math.PI)
      const m = blade.current.material as { opacity: number }
      m.opacity = fade * 0.9
    }
  })
  return (
    <group ref={group} rotation={[0, 0, -0.5]} visible={false}>
      <mesh ref={blade}>
        <planeGeometry args={[6, 0.06]} />
        <meshBasicMaterial color="#dbe9ff" transparent opacity={0} depthWrite={false} blending={AdditiveBlending} />
      </mesh>
      <mesh position={[3, 0, 0]}>
        <sphereGeometry args={[0.09, 8, 6]} />
        <meshBasicMaterial color="#ffffff" transparent opacity={0.9} depthWrite={false} blending={AdditiveBlending} />
      </mesh>
    </group>
  )
}
export function Meteors({ count, profile }: { count: number; profile: SceneProfile }) {
  const items = useMemo(() => Array.from({ length: count }, (_, i) => i + 1), [count])
  if (profile === 'app') return null
  return <>{items.map(seed => <Meteor key={seed} seed={seed} />)}</>
}
