import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { BufferAttribute, Points, ShaderMaterial } from 'three'
import type { SceneProfile } from '../profile'

// A distant flock crossing the sky (Vinland Saga · Your Name) — dark chevrons
// that drift and flap. Drawn as point sprites so a whole skein costs almost
// nothing. Silhouetted against the lighter horizon; hidden inside the app.
export function Birds({ count = 14, profile }: { count?: number; profile: SceneProfile }) {
  const mat = useRef<ShaderMaterial>(null)
  const t = useRef(0)
  const geo = useMemo(() => {
    const pos = new Float32Array(count * 3)
    const seed = new Float32Array(count)
    for (let i = 0; i < count; i++) {
      const r = (n: number) => { const s = Math.sin(i * 45.23 + n) * 43758.5453; return s - Math.floor(s) }
      // a loose skein: clustered but staggered
      pos[i * 3] = (r(1) - 0.5) * 26 + (i - count / 2) * 0.7
      pos[i * 3 + 1] = 14 + r(2) * 6 - Math.abs(i - count / 2) * 0.3
      pos[i * 3 + 2] = -66 - r(3) * 16
      seed[i] = r(4)
    }
    return { pos, seed }
  }, [count])
  const uniforms = useMemo(() => ({ uTime: { value: 0 } }), [])
  useFrame((_, d) => {
    t.current += Math.min(d, 0.05)
    if (mat.current) mat.current.uniforms.uTime.value = t.current
  })
  if (profile === 'app') return null
  return (
    <points frustumCulled={false} position={[0, 0, 0]}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[geo.pos, 3]} />
        <bufferAttribute attach="attributes-seed" args={[geo.seed, 1]} />
      </bufferGeometry>
      <shaderMaterial
        ref={mat}
        transparent
        depthWrite={false}
        uniforms={uniforms}
        vertexShader={`
          uniform float uTime;attribute float aSeed;varying float vFlap;
          void main(){
            vec3 p=position;
            float span=60.;
            p.x=mod(p.x + uTime*(1.1+aSeed*.5) + 30., span) - span*.5;
            p.y+=sin(uTime*.3+aSeed*6.28)*.6;
            vFlap=sin(uTime*(6.+aSeed*3.)+aSeed*10.);
            vec4 mv=modelViewMatrix*vec4(p,1.);
            gl_Position=projectionMatrix*mv;
            gl_PointSize=clamp(260./-mv.z,3.,10.);
          }`}
        fragmentShader={`
          varying float vFlap;
          void main(){
            vec2 c=gl_PointCoord-vec2(.5,.42);
            float wing=abs(c.x)*(.9+vFlap*.35);      // flap raises/lowers the wings
            float line=smoothstep(.06,0.,abs(c.y+wing-.12));
            float span=step(abs(c.x),.5);
            float a=line*span;
            if(a<.05) discard;
            gl_FragColor=vec4(vec3(.06,.08,.10),a*.85);
          }`}
      />
    </points>
  )
}
