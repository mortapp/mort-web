import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { AdditiveBlending, DoubleSide, Group, ShaderMaterial } from 'three'
import type { SceneProfile } from '../profile'

// Volumetric light shafts falling from the moon through the mist (Violet
// Evergarden · Garden of Words). Soft additive blades that sway and breathe,
// giving the air real depth. Angled from whichever side the moon sits on.
function Shaft({ x, w, delay }: { x: number; w: number; delay: number }) {
  const mat = useRef<ShaderMaterial>(null)
  const group = useRef<Group>(null)
  const t = useRef(delay)
  const uniforms = useMemo(() => ({ uTime: { value: delay } }), [delay])
  useFrame((_, d) => {
    t.current += Math.min(d, 0.05)
    if (mat.current) mat.current.uniforms.uTime.value = t.current
    if (group.current) group.current.rotation.z = 0.22 + Math.sin(t.current * 0.13) * 0.03
  })
  return (
    <group ref={group} position={[x, 12, -60]} rotation={[0, 0, 0.22]}>
      <mesh>
        <planeGeometry args={[w, 60]} />
        <shaderMaterial
          ref={mat}
          transparent
          depthWrite={false}
          side={DoubleSide}
          blending={AdditiveBlending}
          uniforms={uniforms}
          vertexShader={`varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`}
          fragmentShader={`uniform float uTime;varying vec2 vUv;
            void main(){
              float edge=1.-abs(vUv.x-.5)*2.;edge=pow(max(0.,edge),1.8);
              float fall=smoothstep(0.,.25,vUv.y)*smoothstep(1.,.35,vUv.y);
              float flick=.72+.28*sin(uTime*.6+vUv.y*6.);
              gl_FragColor=vec4(vec3(.78,.86,.95),edge*fall*flick*.14);
            }`}
        />
      </mesh>
    </group>
  )
}
export function LightShafts({ profile }: { profile: SceneProfile }) {
  const side = profile === 'safety' ? -1 : 1
  const shafts = useMemo(
    () => [
      { x: side * -14, w: 5, delay: 0 },
      { x: side * -7, w: 7, delay: 2.1 },
      { x: side * 0, w: 4, delay: 4.4 },
      { x: side * 8, w: 6, delay: 1.3 },
      { x: side * 16, w: 4.5, delay: 3.2 },
    ],
    [side],
  )
  if (profile === 'app') return null
  return <>{shafts.map((s, i) => <Shaft key={i} {...s} />)}</>
}
