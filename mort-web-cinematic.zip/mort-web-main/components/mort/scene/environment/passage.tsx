import { useMemo, useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { AdditiveBlending, Mesh, PerspectiveCamera, ShaderMaterial, Vector3 } from 'three'
import type { SceneProfile } from '../profile'

// THE PASSAGE — the no-cut travel through the Beacon. As you scroll the hero,
// the camera dollies in (see CameraRig) and the Beacon opens; at the moment you
// pass through its core, this light-warp flashes across the whole view — radial
// streaks stretching from the centre, one unbroken move into the next chapter.
// A quad locked to the camera; scroll drives its intensity, so at rest it's gone.
export function Passage({ profile }: { profile: SceneProfile }) {
  const { camera } = useThree()
  const mesh = useRef<Mesh>(null)
  const mat = useRef<ShaderMaterial>(null)
  const fwd = useMemo(() => new Vector3(), [])
  const uniforms = useMemo(() => ({ uTime: { value: 0 }, uIntensity: { value: 0 } }), [])
  const dist = 1.4
  useFrame((_, d) => {
    const cam = camera as PerspectiveCamera
    const scroll = window.scrollY / Math.max(1, window.innerHeight)
    const p = Math.max(0, Math.min(1, (scroll - 0.12) / (1.25 - 0.12)))
    // flash only through the middle of the passage — the moment of passing through
    const flash = Math.min(1, Math.max(0, (p - 0.28) / 0.22)) * Math.min(1, Math.max(0, (0.86 - p) / 0.24))
    if (mat.current) { mat.current.uniforms.uTime.value += d; mat.current.uniforms.uIntensity.value = flash }
    if (mesh.current) {
      mesh.current.visible = flash > 0.001
      fwd.set(0, 0, -1).applyQuaternion(cam.quaternion)
      mesh.current.position.copy(cam.position).add(fwd.multiplyScalar(dist))
      mesh.current.quaternion.copy(cam.quaternion)
      const h = 2 * dist * Math.tan((cam.fov * Math.PI) / 360)
      mesh.current.scale.set(h * cam.aspect * 1.2, h * 1.2, 1)
    }
  })
  if (profile !== 'home') return null
  return (
    <mesh ref={mesh} renderOrder={1000} visible={false}>
      <planeGeometry args={[1, 1]} />
      <shaderMaterial
        ref={mat}
        transparent
        depthWrite={false}
        depthTest={false}
        blending={AdditiveBlending}
        uniforms={uniforms}
        vertexShader={`varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`}
        fragmentShader={`
          uniform float uTime,uIntensity;varying vec2 vUv;
          float hash(float n){return fract(sin(n)*43758.5453);}
          void main(){
            vec2 c=vUv-0.5; c.x*=1.6;
            float r=length(c);
            float a=atan(c.y,c.x);
            // radial streaks stretching outward, accelerating through the core
            float streak=pow(fract(r*3.0 - uTime*2.2 + hash(floor(a*22.0))*3.0), 3.0);
            streak*=smoothstep(1.0,0.15,r);
            // a bright bloom at the very centre — the core you pass through
            float bloom=smoothstep(0.5,0.0,r);
            vec3 col=vec3(0.80,0.88,1.0)*streak*1.4 + vec3(0.9,0.95,1.0)*bloom*bloom;
            gl_FragColor=vec4(col, (streak*0.7 + bloom*0.9) * uIntensity);
          }`}
      />
    </mesh>
  )
}
