'use client'
import { useEffect, useMemo, useRef } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { OrthographicCamera } from '@react-three/drei'
import { CatmullRomCurve3, Color, DoubleSide, Group, MeshBasicMaterial, Vector3 } from 'three'

// THE CROSSING — a little longship that actually SAILS the route. It travels the
// whole curve continuously, banks into the turns, lights each checkpoint as it
// passes, and loops (fading through the seam). The section's selected stop still
// lights the path up to it, so the widget reads as a living voyage either way.
const SPEED = 0.055
const smooth = (x: number, a: number, b: number) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t) }

function Path({ active, paused }: { active: number; paused: boolean }) {
  const ship = useRef<Group>(null)
  const progress = useRef(active / 5)
  const time = useRef(0)
  const invalidate = useThree(s => s.invalidate)
  const ringMats = useRef<(MeshBasicMaterial | null)[]>([])
  const gemMats = useRef<(MeshBasicMaterial | null)[]>([])
  const litA = useMemo(() => new Color('#bbd8fb'), [])
  const litB = useMemo(() => new Color('#ffffff'), [])
  const dimA = useMemo(() => new Color('#465365'), [])
  const dimB = useMemo(() => new Color('#687a91'), [])
  const curve = useMemo(() => new CatmullRomCurve3([
    new Vector3(-5, 0, 0), new Vector3(-3, .25, -1.4), new Vector3(-1, 0, 1.2),
    new Vector3(1, .3, -1.5), new Vector3(3, 0, .5), new Vector3(5, .25, -1.4),
  ]), [])
  const point = useMemo(() => new Vector3(), [])
  const tangent = useMemo(() => new Vector3(), [])
  const look = useMemo(() => new Vector3(), [])

  useEffect(() => { if (!paused) invalidate() }, [active, paused, invalidate])

  useFrame((_, delta) => {
    if (paused) return
    const dt = Math.min(delta, .05)
    time.current += dt
    progress.current = (progress.current + dt * SPEED) % 1
    const u = progress.current

    // light checkpoints the ship has passed, and always up to the selected stop
    for (let i = 0; i < 6; i++) {
      const lit = i / 5 <= u + 0.02 || i <= active
      ringMats.current[i]?.color.copy(lit ? litA : dimA)
      gemMats.current[i]?.color.copy(lit ? litB : dimB)
    }

    if (ship.current) {
      curve.getPointAt(u, point)
      curve.getTangentAt(u, tangent)
      ship.current.position.copy(point)
      ship.current.position.y += Math.sin(time.current * 4) * 0.03
      look.copy(point).add(tangent)
      ship.current.lookAt(look)
      ship.current.rotateZ(Math.sin(time.current * 3) * 0.06)
      // fade through the loop seam by scaling in/out — no visible teleport
      const edge = Math.min(smooth(u, 0, 0.05), smooth(1 - u, 0, 0.05), 1)
      ship.current.scale.setScalar(0.15 + edge * 0.85)
    }
    invalidate()
  })

  return <group>
    <mesh><tubeGeometry args={[curve, 96, .022, 6, false]} /><meshStandardMaterial color="#a9b9ca" metalness={.6} roughness={.3} /></mesh>
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -.48, 0]}><planeGeometry args={[15, 10]} /><meshStandardMaterial color="#0a0f17" metalness={.6} roughness={.36} transparent opacity={.75} /></mesh>
    {Array.from({ length: 6 }, (_, i) => <group key={i} position={curve.getPoint(i / 5)}>
      <mesh rotation={[Math.PI / 2, 0, 0]}><torusGeometry args={[.23, .014, 6, 32]} /><meshBasicMaterial ref={m => { ringMats.current[i] = m }} color={i <= active ? '#bbd8fb' : '#465365'} /></mesh>
      <mesh rotation={[0, 0, Math.PI / 4]}><boxGeometry args={[.1, .1, .1]} /><meshBasicMaterial ref={m => { gemMats.current[i] = m }} color={i <= active ? '#fff' : '#687a91'} /></mesh>
    </group>)}

    {/* the little longship — bow along +z, a square sail, a bow lantern and a wake */}
    <group ref={ship} position={curve.getPoint(active / 5)}>
      <mesh position={[0, 0.08, 0]} scale={[0.12, 0.1, 0.4]}><octahedronGeometry args={[1, 0]} /><meshStandardMaterial color="#0f1822" metalness={.5} roughness={.5} /></mesh>
      <mesh position={[0, 0.26, 0]}><cylinderGeometry args={[0.008, 0.012, 0.32, 5]} /><meshStandardMaterial color="#26333d" metalness={.5} roughness={.5} /></mesh>
      <mesh position={[0, 0.28, 0]}><planeGeometry args={[0.26, 0.2]} /><meshStandardMaterial color="#e6edf5" side={DoubleSide} metalness={.2} roughness={.7} /></mesh>
      <mesh position={[0, 0.06, 0.22]}><sphereGeometry args={[0.022, 6, 6]} /><meshBasicMaterial color="#ffd7a0" /></mesh>
      <mesh position={[0, 0.02, -0.35]} rotation={[-Math.PI / 2, 0, 0]}><planeGeometry args={[0.18, 0.5]} /><meshBasicMaterial color="#bcd8f5" transparent opacity={0.32} depthWrite={false} /></mesh>
      <pointLight intensity={4} distance={3} color="#c1dbff" />
    </group>
  </group>
}
export default function VoyageCanvas({ active, paused }: { active: number; paused: boolean }) {
  return <Canvas orthographic camera={{ position: [0, 6, 10], zoom: 65, near: .1, far: 100 }} frameloop="demand" dpr={1} gl={{ alpha: true, antialias: true, powerPreference: 'low-power' }}>
    <FitCamera /><ambientLight intensity={1} /><directionalLight position={[-2, 4, 3]} intensity={3} /><Path active={active} paused={paused} />
  </Canvas>
}
function FitCamera() {
  const width = useThree(s => s.size.width)
  return <OrthographicCamera makeDefault position={[0, 6, 10]} zoom={width / 12} near={.1} far={100} onUpdate={camera => camera.lookAt(0, 0, 0)} />
}
