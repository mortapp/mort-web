import { useRef, type RefObject } from 'react'
import { useFrame } from '@react-three/fiber'
import { AdditiveBlending, Group, Mesh } from 'three'
import type { DragState } from './input/drag-state'

// THE MORT BEACON — MORT's own navigational object, standing in the water.
// Matte-black tapered spar · brushed-silver counter-rotating mechanical rings ·
// a frosted-glass faceted core housing · a breathing ice-blue core · a silver
// filament above and a soft halo where it meets the water. It leans toward the
// pointer, and the rings spin up with drag velocity (see input/drag-state).
export function Beacon({ quiet, drag }: { quiet: boolean; drag?: RefObject<DragState> }) {
  const group = useRef<Group>(null)
  const ringA = useRef<Group>(null)
  const ringB = useRef<Group>(null)
  const core = useRef<Group>(null)
  const portal = useRef<Mesh>(null)
  const time = useRef(0)

  useFrame((_, delta) => {
    const dt = Math.min(delta, .05)
    time.current += dt
    const t = time.current
    const energy = drag?.current.energy ?? 0
    const vx = drag?.current.vx ?? 0
    const vy = drag?.current.vy ?? 0
    // THE PASSAGE — scroll opens the Beacon (home only). 0 at rest → 1 as the
    // camera travels through it (see CameraRig / environment/passage).
    const scroll = window.scrollY / Math.max(1, window.innerHeight)
    const pass = quiet ? 0 : Math.max(0, Math.min(1, (scroll - .12) / (1.25 - .12)))
    if (group.current) {
      // idle sway (matches the prior beacon's rest motion) + a lean toward the pointer
      group.current.rotation.y = -.35 + Math.sin(t * .28) * .25 + vx * .16
      group.current.rotation.z = -.17 + Math.sin(t * .32) * .04 + vy * .05
      group.current.position.y = (quiet ? 1 : 2) + Math.sin(t * .65) * .15
    }
    // rings turn always, spin up with drag energy, and SPLAY OPEN with the passage
    if (ringA.current) { ringA.current.rotation.z += dt * (.34 + energy * 3.2 + pass * 4); ringA.current.scale.setScalar(1 + pass * 0.9) }
    if (ringB.current) { ringB.current.rotation.z -= dt * (.52 + energy * 4.1 + pass * 5); ringB.current.scale.setScalar(1 + pass * 1.15) }
    // the core breathes, brighter under interaction, and blooms open through the passage
    if (core.current) core.current.scale.setScalar(1 + Math.sin(t * 1.3) * .12 + energy * .3 + pass * 1.6)
    // the portal — a bloom that grows as you pass through the core
    if (portal.current) {
      portal.current.scale.setScalar(0.2 + pass * 3.4)
      const m = portal.current.material as { opacity: number }
      m.opacity = pass * 0.55
    }
  })

  return (
    <group ref={group} position={[4.5, quiet ? 1 : 2, -3]} scale={quiet ? .8 : 1}>
      {/* frosted-glass faceted core housing */}
      <mesh rotation={[.2, .5, 0]}>
        <icosahedronGeometry args={[1.05, 0]} />
        <meshPhysicalMaterial color="#cfe0f2" transparent opacity={.22} metalness={.1} roughness={.08} clearcoat={1} clearcoatRoughness={.06} />
      </mesh>

      {/* outer brushed-silver ring with an orbiting node (reads as spin) */}
      <group rotation={[1.15, .35, 0]}>
        <group ref={ringA}>
          <mesh><torusGeometry args={[2.25, .05, 10, 96]} /><meshStandardMaterial color="#dfe6ef" metalness={.95} roughness={.18} /></mesh>
          <mesh position={[2.25, 0, 0]}><sphereGeometry args={[.09, 12, 8]} /><meshBasicMaterial color="#eaf4ff" /></mesh>
        </group>
      </group>

      {/* inner ice ring, counter-rotating */}
      <group rotation={[1.05, -.4, .2]}>
        <group ref={ringB}>
          <mesh><torusGeometry args={[1.55, .035, 8, 80]} /><meshStandardMaterial color="#9cc0ee" metalness={.7} roughness={.25} /></mesh>
          <mesh position={[1.55, 0, 0]}><sphereGeometry args={[.07, 10, 8]} /><meshBasicMaterial color="#cfe2ff" /></mesh>
        </group>
      </group>

      {/* breathing ice-blue core + its light */}
      <group ref={core}>
        <mesh><icosahedronGeometry args={[.3, 0]} /><meshBasicMaterial color="#eef7ff" /></mesh>
        <mesh><sphereGeometry args={[.62, 16, 12]} /><meshBasicMaterial color="#9cc0ee" transparent opacity={.32} depthWrite={false} /></mesh>
        <pointLight intensity={quiet ? 3 : 5} distance={9} decay={2} color="#bcd8ff" />
      </group>

      {/* passage portal — a bloom that opens as the camera travels through the core */}
      <mesh ref={portal} scale={0.2}>
        <sphereGeometry args={[1, 24, 18]} />
        <meshBasicMaterial color="#dcecff" transparent opacity={0} depthWrite={false} blending={AdditiveBlending} />
      </mesh>

      {/* silver filament spire above the core */}
      <mesh position={[0, 1.9, 0]} scale={[.022, 1.9, .022]}>
        <octahedronGeometry args={[1, 0]} /><meshBasicMaterial color="#f4f6fc" />
      </mesh>

      {/* tapered matte-black spar reaching down toward the water */}
      <mesh position={[0, -2.3, 0]}>
        <cylinderGeometry args={[.16, .7, 3.6, 8]} />
        <meshStandardMaterial color="#12181f" metalness={.65} roughness={.42} />
      </mesh>
      {/* a brushed-silver edge catching the light down the spar */}
      <mesh position={[.16, -2.3, .16]}>
        <cylinderGeometry args={[.015, .05, 3.6, 4]} />
        <meshStandardMaterial color="#c7cbd1" metalness={.9} roughness={.2} />
      </mesh>

      {/* soft halo where it stands in the water */}
      <mesh rotation={[Math.PI / 2, 0, 0]} position={[0, -4.1, 0]}>
        <ringGeometry args={[1.7, 1.9, 80]} />
        <meshBasicMaterial color="#7fa8d8" transparent opacity={.45} depthWrite={false} />
      </mesh>
    </group>
  )
}
