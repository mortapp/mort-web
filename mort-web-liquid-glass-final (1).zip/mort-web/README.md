# MORT Web — Liquid Glass Edition

MORT is a safe, local teen hustle marketplace: teens (13–17) find nearby paid jobs, adults/businesses post jobs, guardians monitor and approve safety, and admins review verification, reports, and disputes.

This build is a **Next.js 16 (App Router)** app on **Supabase**, redesigned with a rose-gold / baby-blue / soft-pink "liquid glass" UI on a deep black base, with real feature wiring for proof uploads, job-based messaging, guardian approvals, admin review, onboarding, safety, and support tickets.

> **MVP disclaimer:** MORT does not process payments, move money, hold escrow, collect bank/card/SSN data, or make any real background-check, push-notification, or SMS claims. Where the current Supabase schema doesn't support a feature, the UI says so clearly instead of faking it.

---

## 1. Deploy on Vercel

### Option A — Vercel Drop (fastest)
1. Go to [vercel.com/new](https://vercel.com/new) and drag this project folder (or a zip of it) onto the page — or use `vercel deploy` from this folder with the [Vercel CLI](https://vercel.com/docs/cli).
2. When prompted, set the **Environment Variables** listed in section 2 below.
3. Deploy. Vercel auto-detects Next.js.

### Option B — Git import
1. Push this folder to a GitHub/GitLab/Bitbucket repo.
2. In Vercel, "Add New… → Project" → import the repo.
3. Add the environment variables from section 2.
4. Deploy.

Build command: `npm run build` (already verified — see "Build result" note below). Output: standard Next.js `.next` — no special Vercel config needed.

---

## 2. Required environment variables

Set these in Vercel (Project → Settings → Environment Variables) and locally in `.env.local` (copy from `.env.local.example`):

```env
NEXT_PUBLIC_SUPABASE_URL=https://rakjydmgwwgtdislanbt.supabase.co
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=your_publishable_key_here
NEXT_PUBLIC_SITE_URL=https://mort-web.vercel.app
```

- `NEXT_PUBLIC_SUPABASE_URL` / `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` — your Supabase project's URL and **publishable/anon** key (Project Settings → API in Supabase). These are safe to expose in the browser.
- `NEXT_PUBLIC_SITE_URL` — the deployed URL of this app. Used to build auth redirect/callback links.
- **Never** set a Supabase **service role** key in this project. Nothing in the app code reads one, and none should be added — all data access goes through the publishable key and Supabase Row Level Security (RLS).

---

## 3. Supabase auth redirect configuration

In your Supabase project, go to **Authentication → URL Configuration** and set:
- **Site URL**: same value as `NEXT_PUBLIC_SITE_URL`
- **Redirect URLs**: add `${NEXT_PUBLIC_SITE_URL}/auth/callback` and `${NEXT_PUBLIC_SITE_URL}/auth/confirm` (plus `http://localhost:3000/auth/callback` and `.../auth/confirm` for local dev)

The app already implements `/auth/callback`, `/auth/confirm`, `/auth/signout`, and `/auth/auth-code-error`.

---

## 4. Storage setup for proof uploads (required for Feature 1)

Proof uploads uses **direct client-to-Supabase-Storage uploads** (no file passes through a Vercel serverless function, so there's no Vercel body-size limit issue). The UI already handles a missing bucket/policy gracefully and shows a clear warning — but to make proof uploads actually work, run this setup once:

### 4a. Create the bucket
In the Supabase dashboard → **Storage → New bucket**:
- Name: `proof-uploads`
- Public: **OFF** (keep it private — proof photos should not be publicly listable)

Or via SQL:
```sql
insert into storage.buckets (id, name, public)
values ('proof-uploads', 'proof-uploads', false)
on conflict (id) do nothing;
```

### 4b. Storage RLS policies
Files are uploaded under the path `{application_id}/{timestamp}_{filename}`. These policies restrict access using that path plus the `applications`/`jobs` relationship (teen who owns the application, the adult who posted the job, or an admin):

```sql
-- Teens can upload proof for their own applications
create policy "teen can upload own proof"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'proof-uploads'
  and exists (
    select 1 from applications a
    where a.id::text = (storage.foldername(name))[1]
      and a.teen_id = auth.uid()
  )
);

-- Teens can view their own proof; job posters can view proof for their jobs; admins can view all
create policy "read proof if related or admin"
on storage.objects for select
to authenticated
using (
  bucket_id = 'proof-uploads'
  and (
    exists (
      select 1 from applications a
      where a.id::text = (storage.foldername(name))[1]
        and a.teen_id = auth.uid()
    )
    or exists (
      select 1 from applications a
      join jobs j on j.id = a.job_id
      where a.id::text = (storage.foldername(name))[1]
        and j.poster_id = auth.uid()
    )
    or exists (
      select 1 from profiles p where p.id = auth.uid() and p.role = 'admin'
    )
  )
);
```

Adjust table/column names above if your live schema differs from what this build assumes (see section 7).

### 4c. What the app does if this isn't set up yet
- Upload attempts show a friendly error ("bucket does not exist" / "blocked by storage policy") instead of crashing.
- Proof lists on the teen, adult, and admin pages show an inline warning banner with the actual Supabase error, instead of silently showing nothing.

---

## 5. Support ticket schema (Feature 9)

The app expects:
- `support_tickets`: `id, user_id, category, subject, message, status, created_at, updated_at`
- `support_ticket_messages`: `id, ticket_id, sender_id, body, created_at`

`status` is treated as one of `open / in_progress / resolved / closed`. If your live tables use different column names, the Support and Admin pages will surface the exact Postgrest error in a warning banner rather than failing silently — adjust the column names in `app/app/support/actions.ts` and the two support pages to match, or alter your tables to match the names above.

---

## 6. What's fully working

- **Design system v3** — rebuilt against explicit UI/UX principles rather than a simple recolor:
  - **Depth**: dark-mode elevation via discrete brightness steps (`--el-1/2/3`), not blur-on-every-surface. Blur is reserved for the sticky header/sidebar only.
  - **Shadows**: subtle at rest, strongest on popovers/modals/toasts — not the other way around.
  - **Typography**: single family (**Plus Jakarta Sans**, swapped from Inter) — warmer and rounder, reads well for both teens and adults — limited to a 7-size scale, tightened header tracking (-2%/-3%), 115% header line-height.
  - **Spacing**: strict 4pt scale end to end (`--sp-1` … `--sp-20`).
  - **Color**: one primary (rose-gold) with light/dark variants, plus real semantic colors — blue = trust/info, red = error, yellow = warning, green = success only (audited and fixed every leftover decorative use of green).
  - **Buttons**: the default button is a true ghost (outline, no fill) so secondary actions never compete with primary CTAs; explicit hover/active(pressed)/disabled/focus-visible states on every variant.
  - **Overlays**: gradient-to-solid treatment (`.overlay-gradient`, `.overlay-gradient-side`) instead of flat color, used on the login/signup hero panel and landing page hero visual.
- **Micro-interactions** — a real `<Toast>` component (slide-in, auto-dismiss, strips the URL param) replaced the static `?message=` banner across 19 pages; a `<SubmitButton>` (via `useFormStatus`) shows a spinner + pending label on the primary forms (login, signup, onboarding, profile, post-job, message reply, support tickets) instead of a button that does nothing visible until the redirect lands.
- **Reusable components** — `GlassCard`, `MortButton`, `StatusBadge`, `MetricCard`, `PageHeader`, `EmptyState`, `DangerZone`, `RoleBadge`, `JobCard`, `ApplicationCard`, `MessageThreadCard`, `SafetyActionCard`, `AdminReviewCard`, `SegmentedTabs`, `StatusJourney`, skeleton loaders, `Toast`, `SubmitButton` (`components/ui.tsx`, `components/toast.tsx`, `components/submit-button.tsx`).
- **Card hierarchy pass** — `JobCard` now leads with a gradient category-icon tile (fast scanning), title + price sharing the top row (price in accent color, top-right — it used to sit alone at the bottom competing with nothing), and demoted meta/description. Wired into job browse, saved jobs, and the adult's posted-jobs list, replacing duplicate inline markup that still looked like a spreadsheet.
- **Signifiers** — `SegmentedTabs` gives the active category filter a real "lifted" state instead of just a color change; `StatusJourney` renders an application's progress as a connected-dot route (submitted → guardian/adult review → decision) instead of a single flat badge; a `.tooltip` primitive is wired onto icon-only controls and the "guardian required" badge.
- **Icon/avatar tiles everywhere** — every repeating card (jobs, admin review items, challenges, connected teens, applicants, dashboard quick-actions) leads with a gradient icon tile (`.job-card-icon` / `.card-icon-tile` / `.avatar-tile`) instead of a bare floating emoji, so the whole app shares one scannable visual language instead of each page inventing its own.
- **Proof uploads** — teens upload directly to Supabase Storage from `/app/teen/active`; adults see proof on their job's applicant page; admins see a platform-wide proof review table. Signed URLs (1 hour) are generated server-side.
- **Job-based messaging** — threads can only be started from a real application (`startThreadFromApplication`), never a freeform DM. A lightweight keyword scanner flags messages that look like off-platform pressure or contact-info sharing (`clean` / `flagged` statuses). Refresh-based, not realtime (see limitations). Report button on every thread.
- **Guardian approvals** — guardians see applications with status `guardian_pending` from their connected teens and can Approve (→ `submitted`) or Reject (→ `guardian_rejected`), with ownership/connection checks in the server action.
- **Admin review** — business verification approve/reject, report triage (reviewing/resolved/dismissed), user suspend/reactivate, plus new: platform-wide proof review, support ticket management, and a "needs help" safety-ping alert banner.
- **Onboarding** — visual role picker (teen/adult/guardian) with conditional fields, redirects to the right home per role (teen → jobs, adult → verify, guardian → guardian dashboard, admin → admin), and a notice (not a hard block) if onboarding was already completed.
- **Safety center** — SOS / "I'm safe" / custom check-ins, guardian + admin visibility, explicit 911/emergency-services disclaimer, and a note that push/SMS alerts are not implemented (database insert only).
- **Job flow** — browse/filter/apply/save/track for teens; post/review/accept/reject/complete/dispute for adults. Fixed two pre-existing bugs: the adult dashboard was counting jobs via a non-existent `posted_by` column (should be `poster_id`) and applicants via a non-existent `pending` status (now counts `submitted`/`adult_review`).
- **Legal pages** — full draft Terms & Privacy covering every topic requested (guardian involvement, no guaranteed work/payment, off-platform risk, reports/moderation, suspension, safety limitations, emergency disclaimer, and — for privacy — every data category MORT touches), each clearly marked as a draft pending real legal review.
- **Support tickets** — create/list/reply for users, manage/resolve for admins, with graceful fallback if the schema doesn't match.
- **UI polish** — loading skeletons (`app/app/loading.tsx`), error boundaries (`app/error.tsx`, `app/app/error.tsx`), fixed mobile sidebar toggle (was hard-hidden via inline style before), fixed sign-out button (was posting to a non-existent `/api/logout`, now posts to the real `/auth/signout` route), empty states everywhere.

## 7. What's partial / needs your Supabase schema to match

- **Proof uploads** only insert the columns the starter code already used (`application_id, uploaded_by, storage_path, note`). If you want file size/mime type stored, add those columns and extend `recordProofUpload` in `app/app/teen/actions.ts`.
- **Messaging** assumes `message_threads` has `job_id, application_id, teen_id, adult_id, guardian_id, updated_at` and `messages` has `thread_id, sender_id, body, scanner_status, created_at` — this matches the starter's existing query shape (`.or('teen_id.eq...,adult_id.eq...,guardian_id.eq...')`), but wasn't independently verified against a live database.
- **Support tickets** — see section 5. If the tables don't exist yet, the pages show the real error instead of a working list.
- **Team hustles** (`/app/team-hustles`) is intentionally left as a documented placeholder — there's no team/group schema in the known table list, and the brief says not to invent backend structure. It explains exactly what's missing instead of pretending to work.
- **"Mark progress" for in-progress jobs** — not implemented. There's no progress/status field for this in the known schema beyond the application status enum, so it wasn't invented.

## 8. Known limitations (by design)

- **No real-time.** Messages and safety pings are refresh-based (standard Postgres reads on page load / server action redirect), not Supabase Realtime subscriptions.
- **No push/SMS.** Safety pings write to the database only. No push notifications, SMS, or email alerts are sent, and the UI says so on the Safety page.
- **No payments.** MORT never processes, moves, or guarantees payment. Payment preferences (`/app/payments`) are informational only.
- **Message scanner is a basic keyword matcher** (`lib/mort.ts` → `scanMessage`), not an ML/AI moderation pipeline. It flags obvious patterns (phone numbers, "off platform", "don't tell your parent", etc.) — treat it as a first line of defense, not a guarantee.
- **Legal pages are drafts.** Terms and Privacy are original draft copy meant to cover the right topics — they are explicitly not final legal documents and say so on the page.
- **No lint config.** This starter's `package.json` has a `lint` script (`next lint`), but Next 16 removed the auto-scaffolded ESLint config this depended on, and no `.eslintrc`/`eslint.config` file exists in the project. `npm run build` still runs full TypeScript type-checking (and passed cleanly — see below), but there's no separate lint step to run until an ESLint config is added.

## 9. Build result

```
npm ci && npm run build
```
Compiles successfully, TypeScript checks pass, all 30+ routes generate cleanly (verified in this build).

---

## Local development

```bash
npm install
cp .env.local.example .env.local   # then fill in your Supabase values
npm run dev
```

## Project structure

- `app/` — Next.js App Router pages, grouped by `(auth)`, `app/` (authenticated dashboard), `legal/`, `safety/`.
- `components/` — shared UI (`ui.tsx`), app shell/nav (`app-shell.tsx`, `site-header.tsx`), and feature widgets (`proof-upload.tsx`, `onboarding-form.tsx`).
- `lib/` — Supabase client factories (`lib/supabase/`), auth helpers (`lib/auth.ts`), money formatting (`lib/money.ts`), and MORT-specific constants/helpers (`lib/mort.ts` — storage bucket name, file validation, message scanner).
