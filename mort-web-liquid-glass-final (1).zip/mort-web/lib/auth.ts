import { cookies } from 'next/headers'
import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'

type Role = 'teen' | 'adult' | 'guardian' | 'admin'

function hasSupabaseAuthCookie(items: { name: string }[]) {
  return items.some((c) => c.name.startsWith('sb-') || c.name.includes('auth-token'))
}

export async function ensureProfile(supabase: any, user: any, role?: Role | null) {
  const desiredRole = role || user?.user_metadata?.role || null
  const displayName = user?.user_metadata?.display_name || user?.email?.split('@')[0] || 'MORT User'

  const { data: existing } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .maybeSingle()

  if (!existing) {
    await supabase.from('profiles').insert({
      id: user.id,
      role: desiredRole,
      display_name: displayName,
      onboarding_completed: false,
      account_status: 'active',
      verification_status: 'not_started',
      payment_preference: 'none'
    })
  } else {
    const patch: Record<string, unknown> = { updated_at: new Date().toISOString() }
    if (desiredRole && !existing.role) patch.role = desiredRole
    if (!existing.display_name) patch.display_name = displayName
    await supabase.from('profiles').update(patch).eq('id', user.id)
  }
}

export async function getSessionProfile() {
  const cookieStore = await cookies()
  const hasAuth = hasSupabaseAuthCookie(cookieStore.getAll())
  const supabase = await createClient()

  // During Vercel/Next static analysis there is no request auth cookie. Avoid a build-time
  // network call to Supabase Auth and let protected routes redirect normally at request time.
  if (!hasAuth) return { supabase, user: null, profile: null }

  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { supabase, user: null, profile: null }

  await ensureProfile(supabase, user, null)
  const { data: profile } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .maybeSingle()

  return { supabase, user, profile }
}

export async function requireUser() {
  const ctx = await getSessionProfile()
  if (!ctx.user) redirect('/login?message=Sign in first')
  return ctx as { supabase: any; user: any; profile: any }
}

export async function requireRole(roles: Role[]) {
  const ctx = await requireUser()
  if (!ctx.profile?.role || !roles.includes(ctx.profile.role)) {
    redirect('/app/onboarding?message=Choose your MORT role first')
  }
  return ctx
}

export function isVerifiedEnough(profile: any) {
  return profile?.verification_status === 'approved'
}
