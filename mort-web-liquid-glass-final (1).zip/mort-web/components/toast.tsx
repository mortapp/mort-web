'use client'
import { Suspense, useEffect, useState } from 'react'
import { useRouter, usePathname, useSearchParams } from 'next/navigation'

interface Props {
  message?: string | null
  variant?: 'default' | 'error'
}

function ToastInner({ message, variant = 'default' }: Props) {
  const [visible, setVisible] = useState(!!message)
  const [leaving, setLeaving] = useState(false)
  const router = useRouter()
  const pathname = usePathname()
  const searchParams = useSearchParams()

  useEffect(() => {
    setVisible(!!message)
    setLeaving(false)
    if (!message) return
    const timer = setTimeout(() => dismiss(), 4200)
    return () => clearTimeout(timer)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [message])

  function dismiss() {
    setLeaving(true)
    setTimeout(() => {
      setVisible(false)
      const params = new URLSearchParams(searchParams?.toString())
      if (params.has('message')) {
        params.delete('message')
        const qs = params.toString()
        router.replace(qs ? `${pathname}?${qs}` : pathname, { scroll: false })
      }
    }, 200)
  }

  if (!visible || !message) return null

  const isError = variant === 'error' || /fail|error|denied|blocked|not found|cannot|can't/i.test(message)

  return (
    <div className="toast-stack">
      <div className={`toast ${isError ? 'error-toast' : ''} ${leaving ? 'leaving' : ''}`} role="status">
        <span style={{ fontSize: 15, lineHeight: 1 }}>{isError ? '⚠️' : '✅'}</span>
        <span style={{ flex: 1 }}>{message}</span>
        <button className="toast-close" onClick={dismiss} aria-label="Dismiss">✕</button>
      </div>
    </div>
  )
}

/**
 * Reads a `message` prop (typically forwarded from a server-rendered
 * searchParams value after a redirect) and shows it as an animated,
 * auto-dismissing toast — the micro-interaction pattern from the design
 * brief, instead of a static banner that never goes away. Wrapped in
 * Suspense because it uses useSearchParams().
 */
export function Toast(props: Props) {
  return (
    <Suspense fallback={null}>
      <ToastInner {...props} />
    </Suspense>
  )
}
