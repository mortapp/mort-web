import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'

export async function SiteHeader() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  return (
    <header className="site-header">
      <div className="container">
        <Link href="/" className="logo">
          <span className="logo-mark">M</span>
          <span>MORT</span>
        </Link>
        <nav>
          <Link href="/#how" className="hide-mobile">How it works</Link>
          <Link href="/#roles" className="hide-mobile">Roles</Link>
          <Link href="/safety">Safety</Link>
          {user ? (
            <>
              <Link href="/app" className="btn sm" style={{ marginLeft: 8 }}>Dashboard</Link>
            </>
          ) : (
            <>
              <Link href="/login" style={{ marginLeft: 8 }}>Sign in</Link>
              <Link href="/signup" className="btn primary sm" style={{ marginLeft: 4 }}>Get started</Link>
            </>
          )}
        </nav>
      </div>
    </header>
  )
}
