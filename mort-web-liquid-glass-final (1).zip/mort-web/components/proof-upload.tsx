'use client'
import { useRef, useState } from 'react'
import { createClient } from '@/lib/supabase/browser'
import { PROOF_BUCKET, validateProofFile } from '@/lib/mort'
import { recordProofUpload } from '@/app/app/teen/actions'

interface Props {
  applicationId: string
}

export function ProofUpload({ applicationId }: Props) {
  const [file, setFile] = useState<File | null>(null)
  const [note, setNote] = useState('')
  const [status, setStatus] = useState<'idle' | 'uploading' | 'error' | 'done'>('idle')
  const [message, setMessage] = useState<string | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setMessage(null)

    if (!file) {
      setStatus('error')
      setMessage('Choose a photo or short video first.')
      return
    }
    const validationError = validateProofFile(file)
    if (validationError) {
      setStatus('error')
      setMessage(validationError)
      return
    }

    setStatus('uploading')
    try {
      const supabase = createClient()
      const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_')
      const path = `${applicationId}/${Date.now()}_${safeName}`

      const { error: uploadError } = await supabase.storage.from(PROOF_BUCKET).upload(path, file, {
        cacheControl: '3600',
        upsert: false,
        contentType: file.type || undefined,
      })

      if (uploadError) {
        setStatus('error')
        const msg = uploadError.message || ''
        if (/bucket not found/i.test(msg)) {
          setMessage(`Proof storage bucket "${PROOF_BUCKET}" does not exist yet. Ask your MORT admin to finish Supabase Storage setup (see README).`)
        } else if (/row-level security|policy/i.test(msg)) {
          setMessage('Upload blocked by storage security policy. Your account may not have permission to upload proof yet — see README storage setup.')
        } else {
          setMessage(`Upload failed: ${msg}`)
        }
        return
      }

      const fd = new FormData()
      fd.set('application_id', applicationId)
      fd.set('storage_path', path)
      fd.set('note', note)

      const result = await recordProofUpload(fd)
      if (result && result.error) {
        setStatus('error')
        setMessage(`File uploaded, but saving the record failed: ${result.error}`)
        return
      }

      setStatus('done')
      setMessage('Proof uploaded successfully.')
      setFile(null)
      setNote('')
      if (inputRef.current) inputRef.current.value = ''
    } catch (err: any) {
      setStatus('error')
      setMessage(err?.message || 'Something went wrong uploading proof.')
    }
  }

  return (
    <form onSubmit={handleSubmit} className="form" style={{ marginTop: 12 }}>
      <label>
        Proof photo or short video
        <input
          ref={inputRef}
          type="file"
          accept="image/png,image/jpeg,image/webp,image/heic,image/heif,video/mp4,video/quicktime,video/webm"
          onChange={(e) => setFile(e.target.files?.[0] || null)}
        />
      </label>
      <label>
        Note (optional)
        <textarea
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="Describe what you completed..."
        />
      </label>
          <button className="btn primary" type="submit" disabled={status === 'uploading'}>
            {status === 'uploading' && <span className="spinner" aria-hidden="true" />}
            {status === 'uploading' ? 'Uploading…' : 'Upload proof'}
          </button>
      {message && (
        <div className={status === 'error' ? 'error' : 'success-box'} style={{ marginBottom: 0 }}>
          {message}
        </div>
      )}
    </form>
  )
}
