import './globals.css'

export const metadata = {
  title: 'MORT — Teen-safe local hustles',
  description: 'MORT connects teens with safe local jobs, guardian tools, adult posting, moderation, and admin review.'
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>
}
