'use server'
import { redirect } from 'next/navigation'
import { revalidatePath } from 'next/cache'
import { createClient } from '@/lib/supabase/server'
import { getSiteUrl } from '@/lib/site-url'
import { ensureProfile } from '@/lib/auth'

function msg(path: string, message: string) { redirect(`${path}?message=${encodeURIComponent(message)}`) }

export async function signUp(formData: FormData) {
  const supabase = await createClient()
  const email = String(formData.get('email') || '').trim().toLowerCase()
  const password = String(formData.get('password') || '')
  const role = String(formData.get('role') || 'teen') as any
  const displayName = String(formData.get('display_name') || '').trim()
  if (!email || password.length < 6) msg('/signup', 'Use an email and password with at least 6 characters.')

  const redirectTo = `${getSiteUrl()}/auth/callback?next=/app/onboarding`
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: { emailRedirectTo: redirectTo, data: { role, display_name: displayName } }
  })
  if (error) msg('/signup', error.message)
  if (data.user && data.session) {
    await ensureProfile(supabase, data.user, role)
    revalidatePath('/', 'layout')
    redirect('/app/onboarding')
  }
  msg('/login', 'Check your email to verify your account. The link should go to your Vercel site, not localhost.')
}

export async function login(formData: FormData) {
  const supabase = await createClient()
  const email = String(formData.get('email') || '').trim().toLowerCase()
  const password = String(formData.get('password') || '')
  const { error } = await supabase.auth.signInWithPassword({ email, password })
  if (error) msg('/login', error.message)
  revalidatePath('/', 'layout')
  redirect('/app')
}

export async function logout() {
  const supabase = await createClient()
  await supabase.auth.signOut()
  revalidatePath('/', 'layout')
  redirect('/login?message=Signed out')
}

export async function sendPasswordReset(formData: FormData) {
  const supabase = await createClient()
  const email = String(formData.get('email') || '').trim().toLowerCase()
  const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${getSiteUrl()}/auth/callback?next=/update-password` })
  if (error) msg('/reset-password', error.message)
  msg('/login', 'Password reset email sent.')
}

export async function updatePassword(formData: FormData) {
  const supabase = await createClient()
  const password = String(formData.get('password') || '')
  if (password.length < 6) msg('/update-password', 'Password must be at least 6 characters.')
  const { error } = await supabase.auth.updateUser({ password })
  if (error) msg('/update-password', error.message)
  msg('/app/profile', 'Password updated.')
}
