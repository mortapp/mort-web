import Link from 'next/link'
import { sendPasswordReset } from '@/app/(auth)/actions'
export default function ResetPassword(){return <main className="section container" style={{maxWidth:560}}><Link href="/" className="logo"><span className="logo-mark">M</span><span>MORT</span></Link><h1 className="app-title" style={{marginTop:28}}>Reset password</h1><form action={sendPasswordReset} className="card form"><label>Email<input type="email" name="email" required/></label><button className="btn primary">Send reset link</button></form></main>}
