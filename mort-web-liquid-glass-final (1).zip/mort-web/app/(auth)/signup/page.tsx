import Link from 'next/link'
import { signUp } from '@/app/(auth)/actions'
import { Toast } from '@/components/toast'
import { SubmitButton } from '@/components/submit-button'

export default async function Signup({ searchParams }: { searchParams?: Promise<Record<string,string>> }) {
  const sp = await searchParams
  return (
    <main style={{minHeight:'100vh',display:'grid',gridTemplateColumns:'1fr 1fr',background:'var(--bg)'}}>
      {/* Left brand panel */}
      <div style={{
        background:'linear-gradient(145deg, rgba(232,182,164,0.08), rgba(255,179,209,0.05))',
        borderRight:'1px solid var(--border)',
        padding:'48px',
        display:'flex',
        flexDirection:'column',
        justifyContent:'space-between',
        position:'relative',
        overflow:'hidden'
      }}>
        <div style={{position:'absolute',top:'-150px',right:'-100px',width:'400px',height:'400px',background:'radial-gradient(ellipse, rgba(232,182,164,0.14), transparent 65%)',filter:'blur(40px)',pointerEvents:'none'}} />
        <Link href="/" className="logo">
          <span className="logo-mark">M</span>
          <span>MORT</span>
        </Link>
        <div>
          <div className="kicker">Join MORT</div>
          <h1 className="hero-title" style={{marginBottom:20}}>Start your local hustle.</h1>
          <p style={{fontSize:16,color:'var(--muted2)',maxWidth:360,lineHeight:1.7}}>Teens find safe local work. Adults post jobs. Guardians keep everyone safe. It&apos;s free to join.</p>
          <div style={{marginTop:40,display:'flex',flexDirection:'column',gap:16}}>
            {[
              { icon:'🔥', text:'Teens: find dog walking, lawn care, errands & more' },
              { icon:'💼', text:'Adults: post jobs, hire verified teens nearby' },
              { icon:'🛡️', text:'Guardians: protect your teen with safety controls' },
            ].map(item => (
              <div key={item.text} style={{display:'flex',alignItems:'flex-start',gap:12,fontSize:14,color:'var(--muted2)'}}>
                <span style={{fontSize:20}}>{item.icon}</span>
                <span>{item.text}</span>
              </div>
            ))}
          </div>
        </div>
        <p style={{fontSize:12,color:'var(--muted)'}}>MORT — Teen-safe local hustle marketplace</p>
      </div>

      {/* Right form panel */}
      <div style={{padding:'48px',display:'flex',flexDirection:'column',justifyContent:'center',maxWidth:480,margin:'0 auto',width:'100%'}}>
        <h2 style={{marginBottom:8,fontSize:28}}>Create your account</h2>
        <p style={{color:'var(--muted2)',marginBottom:32}}>Free to join. No payment info needed.</p>

        <Toast message={sp?.message} variant="error" />

        <form action={signUp} className="form">
          <label>
            Display name
            <input name="display_name" placeholder="Santiago, Mike, Keke..." />
          </label>
          <label>
            Email address
            <input name="email" type="email" required placeholder="you@example.com" />
          </label>
          <label>
            Password
            <input name="password" type="password" required minLength={6} placeholder="At least 6 characters" />
          </label>
          <label>
            I am a...
            <select name="role" defaultValue="teen">
              <option value="teen">🔥 Teen worker (ages 13–17)</option>
              <option value="adult">💼 Adult / customer / business</option>
              <option value="guardian">🛡️ Guardian / parent</option>
            </select>
          </label>
          <SubmitButton full size="lg" pendingLabel="Creating account…">Create free account</SubmitButton>
        </form>

        <div style={{marginTop:20,textAlign:'center',fontSize:13,color:'var(--muted)'}}>
          Already have an account?{' '}
          <Link href="/login" style={{color:'var(--primary)',fontWeight:600}}>Sign in</Link>
        </div>
        <p style={{fontSize:11,color:'var(--muted)',marginTop:16,textAlign:'center',lineHeight:1.6}}>
          By creating an account you agree to our{' '}
          <Link href="/legal/terms" style={{color:'var(--muted2)'}}>Terms of Service</Link>
          {' '}and{' '}
          <Link href="/legal/privacy" style={{color:'var(--muted2)'}}>Privacy Policy</Link>.
        </p>
      </div>
    </main>
  )
}
