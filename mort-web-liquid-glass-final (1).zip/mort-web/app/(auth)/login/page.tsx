import Link from 'next/link'
import { login } from '@/app/(auth)/actions'
import { Toast } from '@/components/toast'
import { SubmitButton } from '@/components/submit-button'

export default async function Login({ searchParams }: { searchParams?: Promise<Record<string,string>> }) {
  const sp = await searchParams
  return (
    <main style={{minHeight:'100vh',display:'grid',gridTemplateColumns:'1fr 1fr',background:'var(--bg)'}}>
      {/* Left brand panel */}
      <div style={{
        background:'linear-gradient(145deg, rgba(232,182,164,0.08), rgba(143,208,255,0.05))',
        borderRight:'1px solid var(--border)',
        padding:'48px',
        display:'flex',
        flexDirection:'column',
        justifyContent:'space-between',
        position:'relative',
        overflow:'hidden'
      }}>
        <div style={{position:'absolute',top:'-150px',right:'-100px',width:'400px',height:'400px',background:'radial-gradient(ellipse, rgba(232,182,164,0.14), transparent 65%)',filter:'blur(40px)',pointerEvents:'none'}} />
        <div className="overlay-gradient-side" />
        <Link href="/" className="logo" style={{position:'relative'}}>
          <span className="logo-mark">M</span>
          <span>MORT</span>
        </Link>
        <div style={{position:'relative'}}>
          <div className="kicker">Welcome back</div>
          <h1 className="hero-title" style={{marginBottom:20}}>Back to the hustle.</h1>
          <p style={{fontSize:'var(--text-md)',color:'var(--muted2)',maxWidth:360,lineHeight:1.7}}>Your jobs, applications, earnings, and safety tools are waiting for you.</p>
          <div style={{marginTop:40,display:'flex',flexDirection:'column',gap:14}}>
            {['Browse local jobs near you','Track your applications','Check in safely on jobs','Build your XP and reputation'].map(item => (
              <div key={item} style={{display:'flex',alignItems:'center',gap:10,fontSize:'var(--text-base)',color:'var(--muted2)'}}>
                <span style={{color:'var(--primary)',fontSize:16}}>✓</span> {item}
              </div>
            ))}
          </div>
        </div>
        <p className="small" style={{position:'relative'}}>MORT — Teen-safe local hustle marketplace</p>
      </div>

      {/* Right form panel */}
      <div style={{padding:'48px',display:'flex',flexDirection:'column',justifyContent:'center',maxWidth:440,margin:'0 auto',width:'100%'}}>
        <h2 style={{marginBottom:8}}>Sign in to MORT</h2>
        <p style={{color:'var(--muted2)',marginBottom:32,fontSize:'var(--text-sm)'}}>Enter your email and password to continue.</p>

        <Toast message={sp?.message} />

        <form action={login} className="form">
          <label>
            Email address
            <input name="email" type="email" required placeholder="you@example.com" />
          </label>
          <label>
            Password
            <input name="password" type="password" required placeholder="••••••••" />
          </label>
          <SubmitButton full size="lg" pendingLabel="Signing in…">Sign in</SubmitButton>
        </form>

        <div style={{marginTop:20,display:'flex',flexDirection:'column',gap:10}}>
          <Link href="/reset-password" style={{fontSize:'var(--text-sm)',color:'var(--muted2)',textAlign:'center'}}>Forgot your password?</Link>
          <div style={{textAlign:'center',fontSize:'var(--text-sm)',color:'var(--muted)'}}>
            Don&apos;t have an account?{' '}
            <Link href="/signup" style={{color:'var(--primary)',fontWeight:600}}>Create one free</Link>
          </div>
        </div>
      </div>
    </main>
  )
}
