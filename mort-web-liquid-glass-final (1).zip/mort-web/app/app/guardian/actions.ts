'use server'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'
import { requireRole } from '@/lib/auth'

function v(fd: FormData, k: string) { const x = fd.get(k); return x == null ? null : String(x).trim() }

async function assertGuardianOwnsApplication(supabase: any, guardianId: string, applicationId: string) {
  const { data: app } = await supabase
    .from('applications')
    .select('id, teen_id, status')
    .eq('id', applicationId)
    .maybeSingle()
  if (!app) return { app: null, error: 'Application not found.' }

  const { data: connection } = await supabase
    .from('guardian_connections')
    .select('id, status')
    .eq('guardian_id', guardianId)
    .eq('teen_id', app.teen_id)
    .maybeSingle()

  if (!connection || connection.status !== 'active') {
    return { app: null, error: 'This teen is not connected to your guardian account.' }
  }
  if (app.status !== 'guardian_pending') {
    return { app: null, error: 'This application is not waiting on guardian approval.' }
  }
  return { app, error: null }
}

export async function approveApplication(formData: FormData) {
  const { supabase, user } = await requireRole(['guardian', 'admin'])
  const application_id = v(formData, 'application_id')
  if (!application_id) redirect('/app/guardian?message=' + encodeURIComponent('Missing application.'))

  const { error: checkError } = await assertGuardianOwnsApplication(supabase, user.id, application_id!)
  if (checkError) redirect('/app/guardian?message=' + encodeURIComponent(checkError))

  // Approving moves it forward into the normal review flow — the same status
  // a submission gets when no guardian approval is required.
  const { error } = await supabase.from('applications').update({ status: 'submitted' }).eq('id', application_id)
  if (error) redirect('/app/guardian?message=' + encodeURIComponent(error.message))

  revalidatePath('/app/guardian')
  revalidatePath('/app/teen/applications')
  redirect('/app/guardian?message=' + encodeURIComponent('Application approved and sent to the job poster.'))
}

export async function rejectApplication(formData: FormData) {
  const { supabase, user } = await requireRole(['guardian', 'admin'])
  const application_id = v(formData, 'application_id')
  if (!application_id) redirect('/app/guardian?message=' + encodeURIComponent('Missing application.'))

  const { error: checkError } = await assertGuardianOwnsApplication(supabase, user.id, application_id!)
  if (checkError) redirect('/app/guardian?message=' + encodeURIComponent(checkError))

  const { error } = await supabase.from('applications').update({ status: 'guardian_rejected' }).eq('id', application_id)
  if (error) redirect('/app/guardian?message=' + encodeURIComponent(error.message))

  revalidatePath('/app/guardian')
  revalidatePath('/app/teen/applications')
  redirect('/app/guardian?message=' + encodeURIComponent('Application rejected.'))
}
