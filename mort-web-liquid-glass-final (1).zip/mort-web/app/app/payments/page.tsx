import { requireUser } from '@/lib/auth'
import { savePaymentPreference } from '@/app/app/actions'
import { PageHeaderWithActions } from '@/components/ui'
import { SubmitButton } from '@/components/submit-button'
import { Toast } from '@/components/toast'
export const dynamic = 'force-dynamic'

export default async function Payments({ searchParams }: { searchParams?: Promise<Record<string,string>> }) {
  const { supabase, user } = await requireUser()
  const sp = await searchParams
  const { data: pref } = await supabase.from('payment_preferences').select('*').eq('user_id', user.id).maybeSingle()

  return (
    <>
      <PageHeaderWithActions title="Payment preferences" eyebrow="Cash / Cash App">
        <p>MORT does not process, move, or guarantee any payment in this web build. Preferences below are informational only and shared so both sides can agree on how to settle up off-platform.</p>
      </PageHeaderWithActions>
      <Toast message={sp?.message} />

      <div className="warning-box" style={{ marginBottom: 20 }}>
        ⚠️ Fail-closed by design: MORT never collects bank details, card numbers, or SSNs, and never moves money on your behalf.
      </div>

      <form action={savePaymentPreference} className="card form" style={{ maxWidth: 480 }}>
        <label>
          Preference
          <select name="preference" defaultValue={pref?.preference || 'none'}>
            <option value="cash">Cash</option>
            <option value="cash_app">Cash App</option>
            <option value="square_link">Square link</option>
            <option value="flexible">Flexible</option>
            <option value="none">None yet</option>
          </select>
        </label>
        <label>
          Cash App tag
          <input name="cash_app_tag" defaultValue={pref?.cash_app_tag || ''} placeholder="$yourtag" />
        </label>
        <label>
          Square URL
          <input name="square_url" defaultValue={pref?.square_url || ''} />
        </label>
        <label>
          Note
          <textarea name="note" defaultValue={pref?.note || ''} />
        </label>
        <SubmitButton pendingLabel="Saving…">Save preference</SubmitButton>
      </form>
    </>
  )
}
