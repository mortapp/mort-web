'use server'
import { redirect } from 'next/navigation'
import { revalidatePath } from 'next/cache'
import { requireUser, requireRole } from '@/lib/auth'

function v(fd: FormData, k: string) { const x = fd.get(k); return x == null ? null : String(x).trim() }

export async function createSupportTicket(formData: FormData) {
  const { supabase, user } = await requireUser()
  const category = v(formData, 'category') || 'other'
  const subject = v(formData, 'subject') || 'Support request'
  const message = v(formData, 'message') || ''

  const { data, error } = await supabase
    .from('support_tickets')
    .insert({ user_id: user.id, category, subject, message, status: 'open' })
    .select('id')
    .single()

  if (error) redirect(`/app/support?message=${encodeURIComponent('Could not create ticket: ' + error.message)}`)

  revalidatePath('/app/support')
  redirect(`/app/support/${data!.id}?message=${encodeURIComponent('Ticket submitted')}`)
}

export async function replyToTicket(formData: FormData) {
  const { supabase, user, profile } = await requireUser()
  const ticket_id = v(formData, 'ticket_id')
  const body = v(formData, 'body')
  if (!ticket_id || !body) redirect(`/app/support/${ticket_id}?message=${encodeURIComponent('Message cannot be empty.')}`)

  const { data: ticket } = await supabase.from('support_tickets').select('id, user_id, status').eq('id', ticket_id).maybeSingle()
  if (!ticket) redirect('/app/support?message=' + encodeURIComponent('Ticket not found.'))

  const isOwnerOrAdmin = ticket.user_id === user.id || profile?.role === 'admin'
  if (!isOwnerOrAdmin) redirect('/app/support?message=' + encodeURIComponent('You cannot reply to this ticket.'))

  const { error } = await supabase.from('support_ticket_messages').insert({ ticket_id, sender_id: user.id, body })
  if (error) redirect(`/app/support/${ticket_id}?message=${encodeURIComponent('Reply failed: ' + error.message)}`)

  // If an admin replies, nudge the ticket into "in_progress" so it's clear it's being worked.
  if (profile?.role === 'admin' && ticket.status === 'open') {
    await supabase.from('support_tickets').update({ status: 'in_progress', updated_at: new Date().toISOString() }).eq('id', ticket_id)
  }

  revalidatePath(`/app/support/${ticket_id}`)
  redirect(`/app/support/${ticket_id}`)
}

export async function updateSupportTicketStatus(formData: FormData) {
  const { supabase } = await requireRole(['admin'])
  const ticket_id = v(formData, 'ticket_id')
  const status = v(formData, 'status') || 'open'
  const { error } = await supabase.from('support_tickets').update({ status, updated_at: new Date().toISOString() }).eq('id', ticket_id)
  if (error) redirect(`/app/admin?message=${encodeURIComponent(error.message)}`)
  revalidatePath('/app/admin')
  revalidatePath(`/app/support/${ticket_id}`)
  redirect('/app/admin?message=' + encodeURIComponent('Ticket status updated'))
}
