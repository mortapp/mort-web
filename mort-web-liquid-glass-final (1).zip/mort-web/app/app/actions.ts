'use server'
import { redirect } from 'next/navigation'
import { revalidatePath } from 'next/cache'
import { requireUser } from '@/lib/auth'

function toBool(v: FormDataEntryValue | null) { return v === 'on' || v === 'true' || v === 'yes' }
function val(fd: FormData, key: string) { const v = fd.get(key); return v == null ? null : String(v).trim() }

export async function saveOnboarding(formData: FormData) {
  const { supabase, user } = await requireUser()
  const role = val(formData,'role') || 'teen'
  const display_name = val(formData,'display_name') || user.email?.split('@')[0] || 'MORT User'
  const dob = val(formData,'dob') || null
  const city = val(formData,'city') || null
  const state = val(formData,'state') || null
  const username = val(formData,'username') || null

  const { error } = await supabase.from('profiles').upsert({
    id: user.id, role, display_name, dob, city, state, username,
    onboarding_completed: true, updated_at: new Date().toISOString(),
    account_status: 'active', verification_status: 'not_started', payment_preference: 'none'
  })
  if (error) redirect(`/app/onboarding?message=${encodeURIComponent(error.message)}`)

  if (role === 'teen') {
    const skills = String(formData.get('skills') || '').split(',').map(s=>s.trim()).filter(Boolean)
    await supabase.from('teen_profiles').upsert({ user_id: user.id, guardian_approval_required: toBool(formData.get('guardian_required')), paused_by_guardian: false, bio: val(formData,'bio'), skills, school_year: val(formData,'school_year') })
  }
  if (role === 'adult') {
    await supabase.from('adult_profiles').upsert({ user_id: user.id, business_name: val(formData,'business_name'), business_type: val(formData,'business_type') })
  }
  if (role === 'guardian') {
    await supabase.from('guardian_profiles').upsert({ user_id: user.id, emergency_contact_name: val(formData,'emergency_contact_name'), emergency_contact_phone: val(formData,'emergency_contact_phone') })
  }

  revalidatePath('/app','layout')
  const destination = role === 'teen' ? '/app/teen/jobs?message=Welcome to MORT! Start browsing jobs.'
    : role === 'adult' ? '/app/verify?message=Onboarding saved. Verify your business to start posting jobs.'
    : role === 'guardian' ? '/app/guardian?message=Onboarding saved. Connect your teen to get started.'
    : role === 'admin' ? '/app/admin?message=Onboarding saved.'
    : '/app?message=Onboarding saved.'
  redirect(destination)
}

export async function saveProfile(formData: FormData) {
  const { supabase, user } = await requireUser()
  const { error } = await supabase.from('profiles').update({
    display_name: val(formData,'display_name'), username: val(formData,'username'), city: val(formData,'city'), state: val(formData,'state'), dob: val(formData,'dob') || null, updated_at: new Date().toISOString()
  }).eq('id', user.id)
  if (error) redirect(`/app/profile?message=${encodeURIComponent(error.message)}`)
  revalidatePath('/app','layout')
  redirect('/app/profile?message=Profile saved')
}

export async function savePaymentPreference(formData: FormData) {
  const { supabase, user } = await requireUser()
  const preference = val(formData,'preference') || 'none'
  const { error } = await supabase.from('payment_preferences').upsert({ user_id: user.id, preference, cash_app_tag: val(formData,'cash_app_tag'), square_url: val(formData,'square_url'), note: val(formData,'note'), updated_at: new Date().toISOString() })
  await supabase.from('profiles').update({ payment_preference: preference }).eq('id', user.id)
  if (error) redirect(`/app/payments?message=${encodeURIComponent(error.message)}`)
  redirect('/app/payments?message=Payment preference saved')
}

export async function createReport(formData: FormData) {
  const { supabase, user } = await requireUser()
  const { error } = await supabase.from('reports').insert({ reporter_id: user.id, target_user_id: val(formData,'target_user_id') || null, target_job_id: val(formData,'target_job_id') || null, target_message_id: val(formData,'target_message_id') || null, reason: val(formData,'reason') || 'Safety concern', details: val(formData,'details'), status: 'open' })
  if (error) redirect(`/app/reports/new?message=${encodeURIComponent(error.message)}`)
  redirect('/app/safety?message=Report submitted')
}
