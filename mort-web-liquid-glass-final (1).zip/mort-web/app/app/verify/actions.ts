'use server'
import { redirect } from 'next/navigation'
import { revalidatePath } from 'next/cache'
import { requireUser } from '@/lib/auth'
function v(fd: FormData, k: string) { const raw = fd.get(k); return raw == null ? null : String(raw).trim() }
function code(){ return Math.random().toString(36).slice(2,8).toUpperCase() }

export async function createGuardianInvite() {
  const { supabase, user } = await requireUser()
  await supabase.from('profiles').update({ role: 'teen' }).eq('id', user.id)
  const invite_code = code()
  const { error } = await supabase.from('guardian_connections').insert({ teen_id: user.id, status: 'invited', invite_code })
  if (error) redirect(`/app/verify?message=${encodeURIComponent(error.message)}`)
  revalidatePath('/app/verify')
  redirect('/app/verify?message=Guardian invite code created')
}

export async function acceptGuardianInvite(formData: FormData) {
  const { supabase, user } = await requireUser()
  await supabase.from('profiles').update({ role: 'guardian', onboarding_completed: true }).eq('id', user.id)
  await supabase.from('guardian_profiles').upsert({ user_id: user.id })
  const invite_code = String(formData.get('invite_code') || '').trim().toUpperCase()
  const { error } = await supabase.from('guardian_connections').update({ guardian_id: user.id, status: 'active', updated_at: new Date().toISOString() }).eq('invite_code', invite_code).eq('status','invited').is('guardian_id', null)
  if (error) redirect(`/app/verify?message=${encodeURIComponent(error.message)}`)
  redirect('/app/guardian?message=Guardian connection accepted')
}

export async function saveTeenVerification(formData: FormData) {
  const { supabase, user } = await requireUser()
  await supabase.from('profiles').update({ role: 'teen', verification_status: 'pending', updated_at: new Date().toISOString() }).eq('id', user.id)
  await supabase.from('teen_profiles').upsert({ user_id: user.id, guardian_approval_required: formData.get('guardian_approval_required') === 'on', paused_by_guardian: false, bio: v(formData,'bio'), skills: String(formData.get('skills') || '').split(',').map(s=>s.trim()).filter(Boolean), school_year: v(formData,'school_year') })
  redirect('/app/verify?message=Teen verification profile submitted for review')
}

export async function submitBusinessVerification(formData: FormData) {
  const { supabase, user } = await requireUser()
  await supabase.from('profiles').update({ role: 'adult', verification_status: 'pending', updated_at: new Date().toISOString() }).eq('id', user.id)
  await supabase.from('adult_profiles').upsert({ user_id: user.id, business_name: v(formData,'business_name'), business_type: v(formData,'business_type'), verification_notes: v(formData,'notes') })
  const { error } = await supabase.from('business_verifications').insert({ adult_id: user.id, business_name: v(formData,'business_name') || 'Adult customer', business_type: v(formData,'business_type') || 'individual', notes: v(formData,'notes'), status: 'pending' })
  if (error) redirect(`/app/verify?message=${encodeURIComponent(error.message)}`)
  redirect('/app/verify?message=Business/adult verification request submitted')
}
