'use server'
import { redirect } from 'next/navigation'
import { revalidatePath } from 'next/cache'
import { requireRole } from '@/lib/auth'
import { dollarsToCents } from '@/lib/money'
function v(fd: FormData,k:string){const x=fd.get(k); return x==null?null:String(x).trim()}

export async function postJob(formData: FormData) {
  const { supabase, user, profile } = await requireRole(['adult','admin'])
  if (profile?.role !== 'admin' && profile?.verification_status !== 'approved') redirect('/app/verify?message=Adults must be approved before posting jobs.')
  const { error } = await supabase.from('jobs').insert({
    poster_id: user.id,
    title: v(formData,'title') || 'Local job',
    description: v(formData,'description') || 'No description provided',
    category: v(formData,'category') || 'general',
    location_text: v(formData,'location_text') || 'Approximate location shared after approval',
    city: v(formData,'city') || profile?.city || 'Indianapolis',
    state: v(formData,'state') || profile?.state || 'IN',
    pay_amount_cents: dollarsToCents(formData.get('pay_amount')),
    pay_label: v(formData,'pay_label'),
    teen_min_age: Number(v(formData,'teen_min_age') || 13),
    teen_max_age: Number(v(formData,'teen_max_age') || 17),
    requires_guardian_approval: formData.get('requires_guardian_approval') === 'on',
    status: 'open',
    starts_at: v(formData,'starts_at') || null
  })
  if (error) redirect(`/app/adult/post-job?message=${encodeURIComponent(error.message)}`)
  revalidatePath('/app/adult/jobs')
  redirect('/app/adult/jobs?message=Job posted')
}

export async function setApplicationStatus(formData: FormData) {
  const { supabase } = await requireRole(['adult','admin'])
  const application_id = v(formData,'application_id')
  const status = v(formData,'status') || 'adult_review'
  const { error } = await supabase.from('applications').update({ status, updated_at: new Date().toISOString() }).eq('id', application_id)
  if (error) redirect(`/app/adult/applications?message=${encodeURIComponent(error.message)}`)
  redirect('/app/adult/applications?message=Application updated')
}

export async function setJobStatus(formData: FormData) {
  const { supabase, user } = await requireRole(['adult','admin'])
  const job_id = v(formData,'job_id')
  const status = v(formData,'status') || 'paused'
  const { error } = await supabase.from('jobs').update({ status, updated_at: new Date().toISOString() }).eq('id', job_id).eq('poster_id', user.id)
  if (error) redirect(`/app/adult/jobs?message=${encodeURIComponent(error.message)}`)
  redirect('/app/adult/jobs?message=Job updated')
}
