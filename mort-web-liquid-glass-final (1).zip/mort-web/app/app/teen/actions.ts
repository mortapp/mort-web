'use server'
import { redirect } from 'next/navigation'
import { revalidatePath } from 'next/cache'
import { requireRole, requireUser } from '@/lib/auth'

function v(fd: FormData, k: string){ const x=fd.get(k); return x==null?null:String(x).trim() }

export async function applyToJob(formData: FormData) {
  const { supabase, user } = await requireRole(['teen'])
  const job_id = v(formData,'job_id')
  const note = v(formData,'note')
  const { data: teenProfile } = await supabase.from('teen_profiles').select('guardian_approval_required').eq('user_id', user.id).maybeSingle()
  const status = teenProfile?.guardian_approval_required ? 'guardian_pending' : 'submitted'
  const { error } = await supabase.from('applications').insert({ job_id, teen_id: user.id, status, note })
  if (error) redirect(`/app/teen/jobs/${job_id}?message=${encodeURIComponent(error.message)}`)
  revalidatePath('/app/teen/applications')
  redirect(status === 'guardian_pending' ? '/app/teen/applications?message=Application sent to your guardian for approval' : '/app/teen/applications?message=Application submitted')
}

export async function saveJob(formData: FormData) {
  const { supabase, user } = await requireUser()
  const job_id = v(formData,'job_id')
  let { data: folder } = await supabase.from('user_saved_job_folders').select('*').eq('user_id', user.id).eq('name','Saved').maybeSingle()
  if (!folder) { const res = await supabase.from('user_saved_job_folders').insert({ user_id: user.id, name: 'Saved' }).select('*').single(); folder = res.data }
  if (folder) await supabase.from('saved_job_folder_items').insert({ folder_id: folder.id, job_id })
  redirect(`/app/teen/jobs/${job_id}?message=Saved job`)
}

export async function safetyPing(formData: FormData) {
  const { supabase, user } = await requireRole(['teen'])
  const status = v(formData,'status') || 'ok'
  const note = v(formData,'note')
  const { error } = await supabase.from('safety_pings').insert({ teen_id: user.id, status, note })
  if (error) redirect(`/app/safety?message=${encodeURIComponent(error.message)}`)
  redirect('/app/safety?message=Safety ping sent')
}

// Records a proof_uploads row after the client has already uploaded the file
// directly to Supabase Storage (see components/proof-upload.tsx). Returns a
// plain result object instead of redirecting, since this is invoked directly
// from a client component rather than a native form submission.
export async function recordProofUpload(formData: FormData): Promise<{ error?: string; ok?: boolean }> {
  const { supabase, user } = await requireRole(['teen'])
  const application_id = v(formData,'application_id')
  const storage_path = v(formData,'storage_path')
  const note = v(formData,'note')

  if (!application_id || !storage_path) return { error: 'Missing application or file path.' }

  // Confirm the application actually belongs to this teen before recording proof.
  const { data: app } = await supabase.from('applications').select('id, teen_id').eq('id', application_id).maybeSingle()
  if (!app || app.teen_id !== user.id) return { error: 'You can only upload proof for your own applications.' }

  // Only the columns already present in the starter's proof_uploads table are
  // written here (application_id, uploaded_by, storage_path, note). If you add
  // mime_type/file_size columns in Supabase, extend this insert to match.
  const { error } = await supabase.from('proof_uploads').insert({
    application_id,
    uploaded_by: user.id,
    storage_path,
    note,
  })
  if (error) return { error: error.message }

  revalidatePath('/app/teen/active')
  return { ok: true }
}
