import Link from 'next/link'
import { requireUser } from '@/lib/auth'
import { centsToDollars } from '@/lib/money'
import { PageHeaderWithActions, EmptyState, JobCard, SegmentedTabs } from '@/components/ui'
export const dynamic = 'force-dynamic'

const categories = ['All', 'dog walking', 'lawn care', 'cleaning', 'tutoring', 'errands', 'trash help', 'car washing', 'snow shoveling', 'general']
const categoryIconMap: Record<string,string> = { All: '⚡', 'dog walking': '🐕', 'lawn care': '🌿', cleaning: '🧹', tutoring: '📚', errands: '🛒', 'trash help': '🗑️', 'car washing': '🚗', 'snow shoveling': '❄️', general: '✨' }

export default async function Jobs({ searchParams }: { searchParams?: Promise<Record<string,string>> }) {
  const { supabase } = await requireUser()
  const sp = await searchParams
  const category = sp?.category
  const q = sp?.q

  let query = supabase.from('jobs').select('*').eq('status','open').order('created_at',{ascending:false}).limit(60)
  if (category && category !== 'All') query = query.ilike('category', `%${category}%`)
  if (q) query = query.or(`title.ilike.%${q}%,description.ilike.%${q}%`)
  const { data: jobs, error } = await query

  const tabItems = categories.map(c => ({
    key: c,
    label: c === 'All' ? 'All' : c,
    icon: categoryIconMap[c],
    href: c === 'All' ? '/app/teen/jobs' : `/app/teen/jobs?category=${encodeURIComponent(c)}`,
  }))

  return (
    <>
      <PageHeaderWithActions
        title="Find local jobs"
        eyebrow="Teen marketplace"
        description="Apply to jobs near you. Adults review applicants. Guardian approval may be required."
      >
        <Link href="/app/teen/saved" className="btn">🔖 Saved</Link>
        <Link href="/app/teen/applications" className="btn">📋 My apps</Link>
      </PageHeaderWithActions>

      {/* Search */}
      <div className="card" style={{marginBottom:16}}>
        <form style={{display:'flex',gap:12,flexWrap:'wrap',alignItems:'flex-end'}}>
          <label style={{flex:1,minWidth:200}}>
            Search jobs
            <input name="q" placeholder="Dog walking, tutoring, lawn..." defaultValue={q||''} />
          </label>
          <button className="btn primary" style={{marginBottom:0,alignSelf:'flex-end'}}>Search</button>
          {(category || q) && <a href="/app/teen/jobs" className="btn ghost" style={{alignSelf:'flex-end'}}>Clear</a>}
        </form>
      </div>

      {/* Category filter — active segment lifts off the track, matching
          the raised/elevated signifier pattern used for any selected state */}
      <div style={{marginBottom:20}}>
        <SegmentedTabs items={tabItems} activeKey={category || 'All'} />
      </div>

      {error && <div className="error" style={{marginBottom:16}}>{error.message}</div>}

      {!jobs?.length ? (
        <EmptyState
          icon="🔍"
          title="No open jobs yet"
          text="When adults post verified jobs, they show here. Check back soon or try a different category."
          href="/app/teen/saved"
          action="View saved jobs"
        />
      ) : (
        <>
          <div style={{fontSize:13,color:'var(--muted)',marginBottom:16}}>{jobs.length} job{jobs.length !== 1 ? 's' : ''} found</div>
          <div style={{display:'flex',flexDirection:'column',gap:10}}>
            {jobs.map((j: any) => (
              <JobCard
                key={j.id}
                id={j.id}
                title={j.title}
                category={j.category}
                city={j.city}
                state={j.state}
                locationText={j.location_text}
                description={j.description}
                payLabel={j.pay_label || centsToDollars(j.pay_amount_cents)}
                status={j.status}
                requiresGuardianApproval={j.requires_guardian_approval}
                href={`/app/teen/jobs/${j.id}`}
              />
            ))}
          </div>
        </>
      )}
    </>
  )
}
